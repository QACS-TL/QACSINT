using _08ThrowingExceptions;
using System;
using Xunit;

namespace XUnitInvoiceTests
{
    public class InvoiceTests
    {
        string invoiceNumber = "123456";
        DateTime invoiceDate = DateTime.Now.Date;
        decimal grossAmount = 100.00m;
        string customerName = "G. Garvey";
        string description = "3 Packets of Crisps";

        [Fact]
        public void ValidInvoiceDetails()
        {
            //Arrange
            DateTime expectedPaymentDueDate = invoiceDate.AddDays(28);
            decimal expectedNetAmount = 80.00m;
            decimal expectedVATAmount = 20.00m;

            //Act
            Invoice validinvoice = new Invoice(invoiceNumber,
                invoiceDate,
                grossAmount,
                customerName,
                description
            );

            //Assert
            Assert.Equal(expectedPaymentDueDate, validinvoice.PaymentDueDate);
            Assert.Equal(expectedNetAmount, validinvoice.NetAmount);
            Assert.Equal(expectedVATAmount, validinvoice.VATAmount);
        }

        [Fact]
        public void InvalidInvoiceDetailsFutureInvoiceDate()
        {
            //Arrange
            DateTime futureDate = DateTime.Now.Date.AddYears(1);
            Invoice validinvoice = null;
            string expectedErrorMessage = $"Illegal Invoice date! {futureDate:D} is in the future";

            //Act
            IllegalInvoiceDateException ex = Assert.Throws<IllegalInvoiceDateException>(() => validinvoice = new Invoice(invoiceNumber,
                futureDate,
                grossAmount,
                customerName,
                description
            ));

            //Assert
            Assert.Equal(expectedErrorMessage, ex.Message);
        }

        [Fact]
        public void InvalidInvoiceDetailsEarlyPaymentDate()
        {
            //Arrange
            DateTime earlyPaymentDueDate = DateTime.Now.Date.AddYears(-1);
            Invoice validinvoice = null;
            string expectedErrorMessage = $"Illegal Invoice date! payment due date of {earlyPaymentDueDate:D} is earlier than invoice date of {invoiceDate:D}";

            //Act
            IllegalInvoiceDateException ex = Assert.Throws<IllegalInvoiceDateException>(() => validinvoice = new Invoice(invoiceNumber,
                invoiceDate,
                grossAmount,
                customerName,
                description,
                earlyPaymentDueDate
            ));

            //Assert
            Assert.Equal(expectedErrorMessage, ex.Message);
        }

    }
}
