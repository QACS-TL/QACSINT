﻿namespace Utilities
{
    public class Class1
    {

    }
}