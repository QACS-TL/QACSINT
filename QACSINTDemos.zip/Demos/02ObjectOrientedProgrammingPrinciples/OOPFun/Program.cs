﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;

namespace MethodFun
{
    internal class Program
    {   
        public static void Foo( int a)
        {
            a = a + 1;
        }

        public static void Foo(Car v)
        {
            v.Accelerate(20);
        }

        public static Car FindPoolCar()
        {
            Car aCar = null;
            // attempt to make 'aCar'’' point to available Car object
            return aCar;
        }

        public static void ProcessIntArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] += 1;
            }
        }

        public static void ProcessCarArray(Car[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i].Accelerate(10);
            }
        }

        public static void ProcessIntList(List<int> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                list[i] += 1;
            }
        }

        public static void ProcessCarList(List<Car> cars)
        {
            for (int i = 0; i < cars.Count; i++)
            {
                cars[i].Accelerate(10);
            }
        }


        static void Main(string[] args)
        {
            //Classes and Objects Client code for Page 9 and 10
            Car car1 = new Car("Vauxhall", 50, "Black");
            Car car2 = new Car("BMW", 70, "Silver");

            Console.WriteLine($"The {car1.colour} {car1.make} is travelling at {car1.GetSpeed()} mph");
            Console.WriteLine($"The {car2.colour} {car2.make} is travelling at {car2.GetSpeed()} mph");


            // Null Reference Page 11
            Car carPC = FindPoolCar();

            if (carPC != null)
            {
                // Drive the car away
                carPC.Accelerate(30);
            }
            else
            {
                Console.WriteLine("No car available");
            }


            // Lists Revisited Page 12
            List<int> lnums1 = new List<int>();

            List<int> lnums2 = new List<int> { 3, 5, 7, 9 };

            List<Car> lcars1;

            List<Car> lcars2 = new List<Car>();

            List<Car> lcars3 = new List<Car>{
                new Car("Ford", 0, "Blue"),
                new Car("Honda", 20, "Green"),
                new Car("Peugeot", 25, "WHite")
            };

            ProcessIntList(lnums2);
            ProcessCarList(lcars3);

            Console.WriteLine("Content of nums2 array:");
            foreach (int i in lnums2)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("Content of cars3 array:");
            foreach (Car v in lcars3)
            {
                Console.WriteLine($"The {v.make} is travelling at {v.GetSpeed()} mph");
            }


            // ***************** APPENDIX *********************



            // Classic Value Type Behaviour Page 16
            int x = 10;
            int y = x;
            x++;
            Console.WriteLine(x); // 11
            Console.WriteLine(y); // 10
            Foo(x);
            Console.WriteLine(x); // 11

            // Reference Type Behaviour - DIFFERENT! Page 17
            Car c = new Car("Ford", 30, "Red");
            c.Accelerate(10);
            Car d = c;
            d.Accelerate(10);
            Console.WriteLine(c.GetSpeed());
            Console.WriteLine(d.GetSpeed());
            Foo(c);
            Console.WriteLine(c.GetSpeed());

            //Page 18: Passing Parameters by "out"
            //int argNumber;
            //string argText, argOptionalString;
            //OutExampleMethod(out argNumber, out argText, out argOptionalString);
            //Page 19: OR (From C# 7)
            OutExampleMethod(out int argNumber, out string argText, out string argOptionalString);

            Console.WriteLine(argNumber);
            Console.WriteLine(argText);
            Console.WriteLine(argOptionalString == null);
            // Output
            // 42
            // I'm output text
            // True

            //Page 20: Returning Tuples
            var outputs = TupleExampleMethod();
            Console.WriteLine($"Outputs: number is {outputs.number}, text is {outputs.text}");
            Console.WriteLine($"Outputs: optional string is {outputs.optionalString ?? "NULL"}");

            //Pages 21 and 22: Passing Parameters, Value types as "in" - this is the default method
            x = 7;
            Console.WriteLine($"The value before calling the method: {x}");
            SquareANumberUsingIn(x); // Passing the variable by value.
            Console.WriteLine($"The value after calling the method: {x}");
            // The value before calling the method: 7
            // 49
            // The value after calling the method: 7


        }


        // ********************* APPENDIX *********************



        static void OutExampleMethod(out int number, out string text, out string optionalString)
        {
            number = 42;
            text = "I'm output text";
            optionalString = null;
        }

        static (int number, string text, string? optionalString) TupleExampleMethod()
        {
            int number = 42;
            string text = "I'm output text";
            string? optionalString = null;
            return (number, text, optionalString);
        }

        static void SquareANumberUsingIn(in int number)
        {
            Console.WriteLine(number * number);
            //Console.WriteLine(number *= number); //Will error, cannot modify an "in" parameter
            return;
        }
    }
}