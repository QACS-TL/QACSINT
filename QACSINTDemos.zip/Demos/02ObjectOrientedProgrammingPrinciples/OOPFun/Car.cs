﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Formats.Asn1.AsnWriter;

namespace MethodFun
{
    public class Car
    {
        public string make;
        private int speed;
        public string colour;

        public Car(string m, int s, string c )
        {
            make = m;
            speed = s;
            colour = c;

	}

        public void Accelerate(int value)
        {
            speed = speed + value;
        }

        public int GetSpeed() {
            return speed;
        }
    }

}
