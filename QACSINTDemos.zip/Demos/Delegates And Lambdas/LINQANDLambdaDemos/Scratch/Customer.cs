﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scratch
{
    class Customer
    {
        private decimal totalPurchases = 0.00M;
        public decimal TotalPurchases {
            get {
                return totalPurchases;
            }
            set {
                if (value < 0.00M)
                {
                    value = 0.00M;
                }
                totalPurchases = value;
            } 
        }

        public string Name { get; set; }
        public int CustomerId { get; set; }

    }
}
