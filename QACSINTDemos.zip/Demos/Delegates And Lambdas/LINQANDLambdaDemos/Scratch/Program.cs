﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scratch
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers =
                new List<int>() { 12, 4, 56, 8, 44, 2, 11, 10, 9, 17, 44 };

            // LINQ Query syntax
            List<int> orderedNumbersBiggerThan10 = (from n in numbers
                                                    where n > 10
                                                    orderby n
                                                    select n).ToList();

            orderedNumbersBiggerThan10.ForEach(n => Console.Write($"{n} "));

            Console.WriteLine();

            // LINQ Method syntax
            orderedNumbersBiggerThan10 = numbers.Where(n => n > 10).OrderBy(n => n).ToList();

            orderedNumbersBiggerThan10.ForEach(n => Console.Write($"{n} "));
        }
    }
}
