﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Book
    {
        public string Title { get; }
        public decimal Price { get; }
        public int YearPublished { get; }

        public Book(string title, decimal price, int yearPublished)
        {
            Title = title;
            Price = price;
            YearPublished = yearPublished;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Book> books = new List<Book>() {
                new Book("Gullivers Travels", 10M, 1726),
                new Book("War and Peace", 20M, 1869),
                new Book("This is going to hurt", 5M, 2017),
            };

            Console.WriteLine("CHEAP BOOKS V1.0");
            List<Book> cheapBooks = FindCheapBooks(books);
            cheapBooks.ForEach(book =>  Console.WriteLine($"{book.Title}, {book.Price}"));

            Console.WriteLine("\nRECENT BOOKS V1.0");
            List<Book> recentBooks = FindRecentBooks(books);
            recentBooks.ForEach(book => Console.WriteLine($"{book.Title}, {book.YearPublished}"));


            Console.WriteLine("\nCHEAP BOOKS V2.0");

            static bool PriceCondition(Book b)
            {
                return b.Price < 15M;
            }

            List<Book> cheapBooks2 = FindBooks(books, PriceCondition);
            cheapBooks2.ForEach(book => Console.WriteLine($"{book.Title}, {book.Price}"));


            Console.WriteLine("\nCHEAP BOOKS V3.0");
            List <Book> cheapBooks3 = FindBooks(books, b => b.Price < 15M);
            cheapBooks3.ForEach(book => Console.WriteLine($"{book.Title}, {book.Price}"));

            Console.WriteLine("\nRECENT BOOKS V2.0");
            List<Book> recentBooks2 = FindBooks(books, b => b.YearPublished > 2000);
            recentBooks2.ForEach(book => Console.WriteLine($"{book.Title}, {book.YearPublished}"));
        }

        static List<Book> FindCheapBooks(List<Book> books)
        {
            List<Book> output = new List<Book>();
            foreach (Book book in books)
            {
                if (book.Price < 15M)
                {
                    output.Add(book);
                }
            }
            return output;
        }

        static List<Book> FindRecentBooks(List<Book> books)
        {
            List<Book> output = new List<Book>();
            foreach (Book book in books)
            {
                if (book.YearPublished > 2000)
                {
                    output.Add(book);
                }
            }
            return output;
        }

        static List<Book> FindBooks(List<Book> books, Func<Book, bool> func)
        {
            List<Book> output = new List<Book>();
            foreach (Book book in books)
            {
                if (func.Invoke(book))
                {
                    output.Add(book);
                }
            }
            return output;
        }

    }
}
