﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Delegates {
  public class Person {
    public string Name { get; private set; }
    public int Age { get; set; } 
    public string Title { get; private set; }

    public Person(string name, int age, string title) {
      Name = name;
      Age = age;
      Title = title;
    }

    public override string ToString() {
      return string.Format("{0} {1} - {2}", Title, Name, Age);

    }
  }
}
