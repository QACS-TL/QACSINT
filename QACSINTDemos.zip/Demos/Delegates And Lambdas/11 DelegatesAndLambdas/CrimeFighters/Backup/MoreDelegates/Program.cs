﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Delegates
{
  class Program
  {
    static List<Person> people;
    static void Main(string[] args)
    {
      CreateListOfPerson();           // View this method

      Over60AndKnighted();            // uses Predicate<T>
      
      PeopleWithAParticularTitle();   // uses captured 'outer' variable

      SortPeopleByAge();              // uses Comparison<T>         

      GiveEveryOneABirthday();        // uses Action<T>

      FindPeoplesInitials();          // uses Converter<TInput,TOutput>
      
    }
       
    private static void Over60AndKnighted()
    {
      List<Person> olderPeersOfTheRealm;

      Predicate<Person> over60AndKnighted = null;

      over60AndKnighted = delegate(Person p)
      {
        return (p.Title == "Sir" || p.Title == "Dame") && p.Age > 60;

      };
      over60AndKnighted = (Person p) =>
      {
        return (p.Title == "Sir" || p.Title == "Dame") && p.Age > 60;

      };
      over60AndKnighted = (p) =>
      {
        return (p.Title == "Sir" || p.Title == "Dame") && p.Age > 60;

      };
      over60AndKnighted = (p) => {return (p.Title == "Sir" || p.Title == "Dame") && p.Age > 60;};
      over60AndKnighted = p => (p.Title == "Sir" || p.Title == "Dame") && p.Age > 60; 
      
      
      olderPeersOfTheRealm = people.FindAll(over60AndKnighted);

     

      #region This section simply prints those selected
      Console.WriteLine("Knighted and over 60");
      Console.WriteLine("====================");
      PrintPeople(olderPeersOfTheRealm);
      Console.WriteLine();
      # endregion

    }

    private static void PeopleWithAParticularTitle()
    {
      List<Person> peopleOfATitle;

      peopleOfATitle = people.FindAll(MyChoiceOfTitle);

      #region This section simply prints those selected
      Console.WriteLine("People with a particular Title");
      Console.WriteLine("==============================");
      PrintPeople(peopleOfATitle);
      Console.WriteLine();
      # endregion
    }
    private static Predicate<Person> MyChoiceOfTitle
    {
      get
      {
        string title = "Dame";
        return p => p.Title == title;
      }
    }

    private static void SortPeopleByAge()
    {
      Comparison<Person> PersonAgeComparison = (p1, p2) => p1.Age.CompareTo(p2.Age);
      people.Sort(PersonAgeComparison);


      #region This section simply prints the list after sorting
      Console.WriteLine("People Sorted by age");
      Console.WriteLine("====================");
      PrintPeople(people);
      Console.WriteLine();
      # endregion
    }

    private static void GiveEveryOneABirthday()
    {
      people.ForEach(p => p.Age++);


      #region This section simply prints the list after they have all had a birthday
      Console.WriteLine("Here they are after a birthday");
      Console.WriteLine("==============================");
      PrintPeople(people);
      Console.WriteLine();
      # endregion
    }

    private static void FindPeoplesInitials()
    {
      List<string> initials;

      Converter<Person,string> ToInitials = delegate (Person p)
              {
                char firstinitial, secondinitial;
                firstinitial = p.Name[0];
                secondinitial = p.Name[p.Name.IndexOf(' ') + 1];
                return firstinitial + "." + secondinitial;
              };
      //or
      //ToInitials = p => p.Name[0] + "." + p.Name[p.Name.IndexOf(' ') + 1];

      initials = people.ConvertAll(ToInitials);

      #region This section simply prints the list of initials
      Console.WriteLine("Here are their initials");
      Console.WriteLine("=======================");
      initials.ForEach(s => Console.WriteLine(s));
      Console.WriteLine();
      #endregion
    }
    
    private static void CreateListOfPerson() {
      people = new List<Person>();

      Person[] personarray = new[]{
                                    new Person("Mary Whitehouse",92,"Mrs"),
                                    new Person("Judi Dench",58,"Dame"),
                                    new Person("Fred Flintstone",12456,"Mr"),
                                    new Person("Richard Branson", 45, "Sir"),
                                    new Person("Ranulph Fiennes", 68, "Sir"),
                                    new Person("Rebecca Adlington", 21, "Dame"),
                                    new Person("Tiger Woods", 32, "Mr"),
                                    new Person("Desmond Tutu", 56, "Reverend")
                                  };
      people.AddRange(personarray);

    }

    private static void PrintPeople(List<Person> peeps)
    {
      peeps.ForEach(p => Console.WriteLine(p));
     
    }
  }
}
