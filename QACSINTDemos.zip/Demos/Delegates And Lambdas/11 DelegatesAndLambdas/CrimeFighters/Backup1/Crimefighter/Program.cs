using System;
using System.Windows.Forms;

namespace PoliceDispatcher
{
	public class Program
	{
		[STAThread()]
		public static void Main() {
			Application.EnableVisualStyles();
			Application.Run( PoliceDispatcherForm.Instance );	
		}
	}
}
