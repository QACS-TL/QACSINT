using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace PoliceDispatcher
{
	/// <summary>
	/// Summary description for CrimeFighter.
	/// </summary>
	public class CrimeFighter : System.Windows.Forms.UserControl
	{

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblDisplayName;
		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.CheckBox chkOnDuty;
		private bool  onACase;
		private System.Windows.Forms.Timer timerChase;
		private System.ComponentModel.IContainer components;

		public string DisplayName {
			get { return lblDisplayName.Text; }
			set { lblDisplayName.Text = value; }
		}

		public Color DisplayColor {
			get { return panel1.BackColor; }
			set { panel1.BackColor = value; }
		}

		public string Status {
			get { return lblStatus.Text; }
		}

		public bool OnDuty {
			get { return chkOnDuty.Checked; }
		}

		public CrimeFighter()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.panel1 = new System.Windows.Forms.Panel();
			this.chkOnDuty = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.lblDisplayName = new System.Windows.Forms.Label();
			this.lblStatus = new System.Windows.Forms.Label();
			this.timerChase = new System.Windows.Forms.Timer(this.components);
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.Control;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.chkOnDuty);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.lblDisplayName);
			this.panel1.Controls.Add(this.lblStatus);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(304, 120);
			this.panel1.TabIndex = 0;
			// 
			// chkOnDuty
			// 
			this.chkOnDuty.Location = new System.Drawing.Point(8, 80);
			this.chkOnDuty.Name = "chkOnDuty";
			this.chkOnDuty.Size = new System.Drawing.Size(88, 24);
			this.chkOnDuty.TabIndex = 4;
			this.chkOnDuty.Text = "On duty";
			this.chkOnDuty.CheckedChanged += new System.EventHandler(this.OnDutyStatusChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(64, 23);
			this.label2.TabIndex = 3;
			this.label2.Text = "Status:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblDisplayName
			// 
			this.lblDisplayName.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.lblDisplayName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayName.Dock = System.Windows.Forms.DockStyle.Top;
			this.lblDisplayName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDisplayName.Location = new System.Drawing.Point(0, 0);
			this.lblDisplayName.Name = "lblDisplayName";
			this.lblDisplayName.Size = new System.Drawing.Size(300, 32);
			this.lblDisplayName.TabIndex = 2;
			this.lblDisplayName.Text = "Dynamic Duo";
			this.lblDisplayName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblStatus
			// 
			this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblStatus.Location = new System.Drawing.Point(80, 48);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(208, 23);
			this.lblStatus.TabIndex = 3;
			this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// timerChase
			// 
			this.timerChase.Tick += new System.EventHandler(this.OnTimerTicked);
			// 
			// CrimeFighter
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.panel1);
			this.Name = "CrimeFighter";
			this.Size = new System.Drawing.Size(304, 120);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		// TODO: Dynamically connect and disconnect to the CrimeReported event
		//       depending on whether this CrimeFighter is on duty or not
		private void OnDutyStatusChanged(object sender, System.EventArgs e) {
			if( OnDuty ) {
				lblStatus.Text = "Patrolling the streets";
				//PoliceDispatcherForm.Central.CrimeReported += new CrimeReportedEventHandler( OnCrimeReported);

        // Inferred delegate syntax 
        PoliceDispatcherForm.Instance.CrimeReported += OnCrimeReported;
               
			}
			else {
				lblStatus.Text = "";
				//PoliceDispatcherForm.Central.CrimeReported -= new CrimeReportedEventHandler( OnCrimeReported);
        PoliceDispatcherForm.Instance.CrimeReported -= OnCrimeReported;
			}
			onACase = false;
		}

    private CrimeReportedEventArgs activeCrimeReport;

		// TODO: Implement a method to respond to the CrimeReported event
		private void OnCrimeReported(object sender, CrimeReportedEventArgs e) {
			if( e.CrimeFighterOnCase == null && !onACase ) {
				e.CrimeFighterOnCase = this;
        activeCrimeReport = e;     //must not allow e to go out of scope without saving it first 
				lblStatus.Text = "Responding to " + e.Crime + " at " + e.Location;
				onACase = true;
				ChaseVillains();

			}
		}


		// TODO: - Implement a ChaseVillains method to chase down the villains
		private void ChaseVillains() {
			Random r = new Random( Environment.TickCount );
			timerChase.Interval = r.Next( 1000, 5000 );
			timerChase.Enabled = true;
		}

		private void OnTimerTicked(object sender, System.EventArgs e) {
			timerChase.Enabled = false;
			onACase = false;
			lblStatus.Text = "Patrolling the streets";
			OnVillainCaptured( activeCrimeReport );  // same pattern - private calls the overridable protected
		}

		protected virtual void OnVillainCaptured( CrimeReportedEventArgs e ) {
      if (VillainCaptured != null)
      {    // did anyone register an interest
        VillainCaptured(this, e);
      }
		}

	
		
    //public event CrimeReportedEventHandler VillainCaptured;
    public event EventHandler<CrimeReportedEventArgs> VillainCaptured; // since c#2.0

	}
}
