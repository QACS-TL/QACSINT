using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PoliceDispatcher
{
	/// <summary>
	/// Summary description for CrimeFighters.
	/// </summary>
	public class CrimeFightersForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private PoliceDispatcher.CrimeFighter cfDynamicDuo;
		private PoliceDispatcher.CrimeFighter cfSpiderman;
		private PoliceDispatcher.CrimeFighter cfClouseau;
		private PoliceDispatcher.CrimeFighter cfPCPlod;
		private bool  _allowToClose = false;

		public CrimeFightersForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cfDynamicDuo = new PoliceDispatcher.CrimeFighter();
			this.cfSpiderman = new PoliceDispatcher.CrimeFighter();
			this.cfClouseau = new PoliceDispatcher.CrimeFighter();
			this.cfPCPlod = new PoliceDispatcher.CrimeFighter();
			this.SuspendLayout();
			// 
			// cfDynamicDuo
			// 
			this.cfDynamicDuo.BackColor = System.Drawing.SystemColors.Control;
			this.cfDynamicDuo.DisplayColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cfDynamicDuo.DisplayName = "Dynamic Duo";
			this.cfDynamicDuo.Dock = System.Windows.Forms.DockStyle.Top;
			this.cfDynamicDuo.Location = new System.Drawing.Point(0, 0);
			this.cfDynamicDuo.Name = "cfDynamicDuo";
			this.cfDynamicDuo.Size = new System.Drawing.Size(490, 120);
			this.cfDynamicDuo.TabIndex = 0;
			// 
			// cfSpiderman
			// 
			this.cfSpiderman.BackColor = System.Drawing.SystemColors.Control;
			this.cfSpiderman.DisplayColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(192)), ((System.Byte)(192)));
			this.cfSpiderman.DisplayName = "Spiderman";
			this.cfSpiderman.Dock = System.Windows.Forms.DockStyle.Top;
			this.cfSpiderman.Location = new System.Drawing.Point(0, 120);
			this.cfSpiderman.Name = "cfSpiderman";
			this.cfSpiderman.Size = new System.Drawing.Size(490, 120);
			this.cfSpiderman.TabIndex = 1;
			// 
			// cfClouseau
			// 
			this.cfClouseau.BackColor = System.Drawing.SystemColors.Control;
			this.cfClouseau.DisplayColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cfClouseau.DisplayName = "Inspector Clouseau";
			this.cfClouseau.Dock = System.Windows.Forms.DockStyle.Top;
			this.cfClouseau.Location = new System.Drawing.Point(0, 240);
			this.cfClouseau.Name = "cfClouseau";
			this.cfClouseau.Size = new System.Drawing.Size(490, 120);
			this.cfClouseau.TabIndex = 2;
			// 
			// cfPCPlod
			// 
			this.cfPCPlod.BackColor = System.Drawing.SystemColors.Control;
			this.cfPCPlod.DisplayColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.cfPCPlod.DisplayName = "PC Plod";
			this.cfPCPlod.Dock = System.Windows.Forms.DockStyle.Top;
			this.cfPCPlod.Location = new System.Drawing.Point(0, 360);
			this.cfPCPlod.Name = "cfPCPlod";
			this.cfPCPlod.Size = new System.Drawing.Size(490, 120);
			this.cfPCPlod.TabIndex = 3;
			// 
			// CrimeFightersForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(490, 479);
			this.ControlBox = false;
			this.Controls.Add(this.cfPCPlod);
			this.Controls.Add(this.cfClouseau);
			this.Controls.Add(this.cfSpiderman);
			this.Controls.Add(this.cfDynamicDuo);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CrimeFightersForm";
			this.ShowInTaskbar = false;
			this.Text = "CrimeFighters";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.CrimeFightersForm_Closing);
			this.ResumeLayout(false);

		}
		#endregion
	
		public void CloseForm() {
			_allowToClose = true;
			Close();
		}

		private void CrimeFightersForm_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			e.Cancel = !_allowToClose;
		}
	
	}


}
