using System;

namespace PoliceDispatcher
{
	// TODO: Define a new CrimeReportedEventArgs type that will contain
	//       information about the crime that has been reported
	public class CrimeReportedEventArgs : EventArgs
	{
		public readonly string Crime;
		public readonly string Location;
    public string ReasonUnsolved { get; set; }

    // C#3 auto-implemented property.
    public CrimeFighter CrimeFighterOnCase { get; set; }
    
    // C#2 technique
    //private CrimeFighter crimeFighterOnCase;
 
    //public CrimeFighter CrimeFighterOnCase {
    //  get { return crimeFighterOnCase; }
    //  set { crimeFighterOnCase = value; }
    //}

		public CrimeReportedEventArgs( string crime, string location ) {
			Crime = crime;
			Location = location;
		}

	}

	// TODO: Define the delegate signature for the CrimeReported event
	//public delegate void CrimeReportedEventHandler( object sender, CrimeReportedEventArgs e );
}
