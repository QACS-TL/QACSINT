﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DelegatesAndLambdas
{
//IPlayable.cs
//============

public interface IPlayable
{
    void Play(ProgressDelegate progressDel);
}

public delegate void ProgressDelegate(int percent);

public class Song : IPlayable
{

    //Now replace Play in Song with
    public void Play(ProgressDelegate progressDel)
    {
        SetPlayStatus();
        MethodInvoker mi = new MethodInvoker(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    progressDel.Invoke(i);
                    Thread.Sleep(100);
                }
            });
        mi.Invoke();
    }

    private void SetPlayStatus()
    {
        throw new NotImplementedException();
    }
}

//MainForm.cs
//===========
public class MainForm : Form
{

    ProgressBar playProgress;
    Song mediaItem;
    void SomeMethod()
    {
        mediaItem.Play(UpdateProgressBar); // new
    }
    private void UpdateProgressBar(int percent)
    { // new
        int pc = Math.Max(Math.Min(percent, 100), 0);
        if (this.InvokeRequired)
        {
            MethodInvoker mi = new MethodInvoker(
                () => playProgress.Value = pc);
            this.Invoke(mi);
        }
        else
        {

            playProgress.Value = pc;
        }
    }
}
}
