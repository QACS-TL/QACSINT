﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DelegatesAndLambdas
{
    class Program
    {
        static List<Item> items = GetItems();

        static void Main(string[] args)
        {
            //WithoutDelegates();
            //NamedInstanceOfDelegate();
            //MethodGroup();
            //AnonymousDelegate();
            //LambdaFunction();
            //VariableInTraditionalDelegate();
            //CapturedVariableInLambda();

            ArgumentsToLambda();

            Console.ReadLine();
        }

        private static void WithoutDelegates()
        {
            List<Item> result = Where(items);
            PrintItems(result);
        }

        private static void NamedInstanceOfDelegate()
        {
            //with a named instance of a delegate:
            CodeCaller del = new CodeCaller(MyTest);
            List<Item> result = Where(items, del);
            PrintItems(result);
        }

        private static void MethodGroup()
        {
            //with a "MethodGroup" (compiler sees what we're doing, news up a CodeCaller for us):
            List<Item> result = Where(items, MyTest);
            PrintItems(result);
        }

        private static void AnonymousDelegate()
        {
            //using an anonymous delegate:
            List<Item> result = Where(items,
                delegate(Item item)
                {
                    return item.ValueForFilter.Contains("e");
                });
            PrintItems(result);
        }

        private static void LambdaFunction()
        {
            //lambda function:
            List<Item> result = Where(items, item => item.ValueForFilter.Contains("e"));
            PrintItems(result);
        }

        private static void VariableInTraditionalDelegate()
        {
            //variable in traditional delegate:
            Console.WriteLine("What letter are you looking for?");
            globalVariable = Console.ReadLine();
            List<Item> result = Where(items, MyVariableTest);
            PrintItems(result);
        }

        private static void CapturedVariableInLambda()
        {
            //captured variable in lambda:
            Console.WriteLine("What letter are you looking for?");
            string capturedVariable = Console.ReadLine();
            List<Item> result = Where(items, item => item.ValueForFilter.Contains(capturedVariable));
            PrintItems(result);
        }

        static List<Item> Where(List<Item> items)
        {
            List<Item> output = new List<Item>();
            foreach (Item item in items)
            {
                if (item.ValueForFilter.Contains("e"))
                {
                    output.Add(item);
                }
            }
            return output;
        }

        static bool MyTest(Item item)
        {
            return item.ValueForFilter.Contains("e");
        }

        static string globalVariable = "e";

        static bool MyVariableTest(Item item)
        {
            return item.ValueForFilter.Contains(globalVariable);
        }

        static List<Item> Where(List<Item> items, CodeCaller del)
        {
            List<Item> output = new List<Item>();
            foreach (Item item in items)
            {
                //if (del.Invoke(item))
                if (del(item)) //a delegate exists to be invoked!
                {
                    output.Add(item);
                }
            }
            return output;
        }

        static List<Item> GetItems()
        {
            return new List<Item>{
                new Item { ValueForFilter = "One" },
                new Item { ValueForFilter = "Two" },
                new Item { ValueForFilter = "Three" },
                new Item { ValueForFilter = "Four" },
                new Item { ValueForFilter = "Five" },
                new Item { ValueForFilter = "Six" },
                new Item { ValueForFilter = "Seven" },
                new Item { ValueForFilter = "Eight" },
                new Item { ValueForFilter = "Nine" },
                new Item { ValueForFilter = "Ten" },
            };
        }

        static void PrintItems(List<Item> items)
        {
            items.ForEach(i => Console.WriteLine(i.ValueForFilter));
        }

        static void ArgumentsToLambda()
        {
            StringChopper sc = new StringChopper(
                (s, i) => s.Substring(0, i));
            MethodInvoker mi = new MethodInvoker(
                () =>
                {
                    foreach (Item item in items)
                    {
                        Console.WriteLine(sc.Invoke(item.ValueForFilter, 3));
                    }
                });
            mi.Invoke();
        }
    }

    public delegate bool CodeCaller(Item item);

    public delegate string StringChopper(string input, int length);

    public class CodeCallerPseudoCode
    {
        PointerToObject po;
        PointerToCode pc;
        CodeCallerPseudoCode(PointerToObject po, PointerToCode pc)
        {
            this.po = po; this.pc = pc;
        }
        public bool Invoke(Item item)
        {
            //...invoke the code pointed to by po.pc;
            return true;
        }
    }
}
