using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace PlaneSimulator.Controls
{
	public partial class PlaneSource : UserControl
	{
        Image newImage = null;

        public PlaneSource()
        {
            InitializeComponent();
       }
           

		protected override void OnPaint( PaintEventArgs e )
		{
			base.OnPaint( e );
			Rectangle rct = ClientRectangle;
			rct.Inflate( -15, -5 );
			//e.Graphics.DrawRectangle( Pens.Cyan, rct );
		}

		protected override void OnMouseDown( MouseEventArgs e )
		{
			base.OnMouseDown( e );
			if( e.Button == MouseButtons.Left )
			{
				DataObject da = new DataObject( DragPlaneType.Format, new DragPlaneType() ); 
				DoDragDrop( da, DragDropEffects.Move );
			}
		}
		
		
		public class DragPlaneType
		{
			public static string Format = "DragPlaneTypeCS";
		}
		
	}
}
