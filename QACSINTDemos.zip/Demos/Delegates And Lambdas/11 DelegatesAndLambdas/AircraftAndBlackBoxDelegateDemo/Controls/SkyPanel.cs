using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Planes;

namespace PlaneSimulator.Controls
{
	public partial class SkyPanel : UserControl, INotifyPropertyChanged
	{
        int planeNumber = 0;
        PlaneSource ps = new PlaneSource();

		private bool drawDataBlock;

		private List<Plane> planes;

		public SkyPanel()
		{
			InitializeComponent();
			this.DoubleBuffered = true;
			this.ResizeRedraw = true;
			planes = new List<Plane>();
           
 		}

		protected override void OnPaint(PaintEventArgs e )
		{
			Graphics canvas = e.Graphics;
			RenderPlanes(canvas);
			if( DrawDataBlocks ) 
			{
				RenderDataBlocks(canvas);
			}
		}

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);

            base.OnMouseClick(e);

            foreach (Plane v in planes)
            {
                Rectangle r = GetRectangleForPlane(v);
                if (r.Contains(e.Location))
                {
                    if (e.Delta > 0)
                    {
                        v.Accelerate(1);
                    }
                    else if (e.Delta < 0)
                    {
                        v.Brake(1);
                    }

                    Invalidate();
                    break;
                }
            }
        }

        protected override void OnMouseClick( MouseEventArgs e )
		{
			base.OnMouseClick(e);

			foreach( Plane v in planes )
			{
				Rectangle r = GetRectangleForPlane(v);
				if( r.Contains(e.Location) )
				{
					if( e.Button == MouseButtons.Left  )
					{
						v.Ascend(10);
					}
					else if( e.Button == MouseButtons.Right )
					{
						v.Descend(10);
					}

                    Invalidate();
					break;
				}
			}
		}
		
		private void RenderPlanes( Graphics canvas )
		{
            Image planeImg = ps.BackgroundImage;
			foreach( Plane v in planes )
			{
                canvas.DrawImage(planeImg, GetRectangleForPlane(v));
			}
		}		

		private Rectangle GetRectangleForPlane( Plane v )
		{
            int ypos = this.Height - v.Altitude - 10;
            return new Rectangle(v.Position - 16, ypos - 8, 32, 16);
		}

		private void RenderDataBlocks( Graphics canvas ) 
		{
			Font fnt = new Font("Courier new", 8);
			int h = (int) fnt.GetHeight(canvas);
			int xAdd = 15;
			int yNeg = 40;
			int yPos;

			foreach( Plane v in planes )
			{
				string[] s = v.GetDataBlock().Split(',', ' ');
				yPos = this.Height - v.Altitude - 10;
                canvas.DrawString("Name: " + s[0], fnt, Brushes.Black, v.Position + xAdd, yPos - yNeg);
                canvas.DrawString("Spd: " + s[1], fnt, Brushes.Black, v.Position + xAdd, yPos - yNeg + h);
                canvas.DrawString("Height: " + s[3], fnt, Brushes.Black, v.Position + xAdd, yPos - yNeg + 2 * h);
                canvas.DrawLine(Pens.Black, v.Position, yPos, v.Position + xAdd, yPos - yNeg + 2 * h);
			}

			fnt.Dispose();
		}

		public bool DrawDataBlocks
		{
			get
			{
				return drawDataBlock;
			}
			set
			{
				drawDataBlock = value;
				Invalidate();
			}
		}

		public bool Running
		{
			get
			{
				return timerUpdate.Enabled;
			}
		}

		public void Start()
		{
			timerUpdate.Enabled = true;
			OnPropertyChanged( new System.ComponentModel.PropertyChangedEventArgs( "Running" ) );
		}

		public void Stop()
		{
			timerUpdate.Enabled = false;
			Invalidate();
			OnPropertyChanged( new System.ComponentModel.PropertyChangedEventArgs( "Running" ) );
		}

		public void Reset()
		{
			planes.Clear();
			this.Stop();
		}

		private void timerUpdate_Tick( object sender, EventArgs e )
		{
			if( planes.Count == 0 )
			{
				this.Stop();
				return;
			}

			for( int i = planes.Count - 1; i >= 0; i-- )
			{
				planes[i].Updateposition();
				if( planes[i].Position > this.ClientRectangle.Right )
				{
					planes.RemoveAt( i );
				}
			}
			this.Invalidate();
		}

		protected override void OnDragEnter( System.Windows.Forms.DragEventArgs drgevent )
		{
			base.OnDragEnter( drgevent );
			if( drgevent.Data.GetDataPresent( PlaneSource.DragPlaneType.Format ) )
			{
				drgevent.Effect = DragDropEffects.Move;
			}
		}

		protected override void OnDragOver( System.Windows.Forms.DragEventArgs drgevent )
		{
			base.OnDragOver( drgevent );
			if( drgevent.Data.GetDataPresent( PlaneSource.DragPlaneType.Format ) )
			{
				drgevent.Effect = DragDropEffects.Move;
			}
		}

		protected override void OnDragDrop( System.Windows.Forms.DragEventArgs drgevent )
		{
			base.OnDragDrop( drgevent );
			if( drgevent.Data.GetDataPresent( PlaneSource.DragPlaneType.Format ) )
			{
				Point pt = new Point( drgevent.X, drgevent.Y );
				pt = PointToClient( pt );
                pt = CreatePlane(pt);

				drgevent.Effect = DragDropEffects.Move;

				Invalidate();
				
			}
		}

        private Point CreatePlane(Point pt)
        {
            string name = "Jumbo" + GenerateNextPlaneNumber();
            Plane veh = new Plane(10, pt.X, this.Height - pt.Y, name);
            planes.Add(veh);
            return pt;
        }

		protected virtual void OnPropertyChanged(PropertyChangedEventArgs e )
		{
			if( PropertyChanged != null )
			{
				PropertyChanged( this, e );
			}
		}

        public void CreateDependentPlane(string name)
        {
            name += GenerateNextPlaneNumber();

            Plane dependentPlane = new Plane(name);
            planes.Add(dependentPlane);
            BlackBoxRecorder dependentPlaneRecorder = new BlackBoxRecorder(dependentPlane);
 
            Invalidate();
        }

        public void CreateIndependentPlane(string name)
        {
            name += GenerateNextPlaneNumber();

            Plane independentPlane = new Plane(name);
            planes.Add(independentPlane);
            BlackBoxRecorder independentRecorder = new BlackBoxRecorder();
            independentPlane.TrackSubscriber(independentRecorder.AltitudeChangedRecorder);

            Invalidate();
        }


        public void CreateEventDrivenPlane(string name)
        {
            name += GenerateNextPlaneNumber();

            Plane eventDrivenPlane = new Plane(name);
            planes.Add(eventDrivenPlane);

            BlackBoxRecorder eventDrivenRecorder = new BlackBoxRecorder();
            eventDrivenPlane.altitudeChangedEvent += eventDrivenRecorder.AltitudeChangedHandler;


            Invalidate();
        }

        private string GenerateNextPlaneNumber()
        {
            return string.Format("{0:00}", ++planeNumber);
        }


		public event PropertyChangedEventHandler PropertyChanged;

	}
}

