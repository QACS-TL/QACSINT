using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PlaneSimulator
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void btnExit_Click( object sender, EventArgs e )
		{
			if( MessageBox.Show("Are you SURE that you want to exit?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes )
			{
				this.Close();
			}
		}

		private void chkDisplayData_CheckedChanged( object sender, EventArgs e )
		{
			skyPanel.DrawDataBlocks = chkDisplayData.Checked;
		}

		private void btnStart_Click( object sender, EventArgs e )
		{
			if( skyPanel.Running )
			{
				skyPanel.Stop();
			}
			else
			{
				skyPanel.Start();
			}
		}

		private void btnReset_Click( object sender, EventArgs e )
		{
			skyPanel.Reset();
		}

		private void mwayPanel_PropertyChanged( object sender, PropertyChangedEventArgs e )
		{
			if( skyPanel.Running )
			{
				btnStart.Text = "&Stop";
			}
			else
			{
				btnStart.Text = "&Start";
			}
		}


        private void btnDependantPlane_Click(object sender, EventArgs e)
        {
            string name = "DEPL";
            skyPanel.CreateDependentPlane(name);
        }

        private void btnIndependantPlane_Click(object sender, EventArgs e)
        {
            string name = "INDP";
             skyPanel.CreateIndependentPlane(name);
        }

        private void btnEventDrivenPlane_Click(object sender, EventArgs e)
        {
            string name = "EVTP";
            skyPanel.CreateEventDrivenPlane(name);
        }



	}
}