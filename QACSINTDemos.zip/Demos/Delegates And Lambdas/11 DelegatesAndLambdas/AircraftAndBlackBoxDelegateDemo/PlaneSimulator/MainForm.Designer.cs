namespace PlaneSimulator
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnReset = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.chkDisplayData = new System.Windows.Forms.CheckBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.skyPanel = new PlaneSimulator.Controls.SkyPanel();
            this.planeSource1 = new PlaneSimulator.Controls.PlaneSource();
            this.btnDependantPlane = new System.Windows.Forms.Button();
            this.btnIndependantPlane = new System.Windows.Forms.Button();
            this.btnEventDrivenPlane = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Location = new System.Drawing.Point(735, 432);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 10;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(255, 396);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(335, 13);
            this.Label1.TabIndex = 8;
            this.Label1.Text = "Left click a plane to make it ascend. Right click it to make it descend.";
            // 
            // chkDisplayData
            // 
            this.chkDisplayData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkDisplayData.AutoSize = true;
            this.chkDisplayData.Location = new System.Drawing.Point(12, 436);
            this.chkDisplayData.Name = "chkDisplayData";
            this.chkDisplayData.Size = new System.Drawing.Size(118, 17);
            this.chkDisplayData.TabIndex = 7;
            this.chkDisplayData.Text = "&Display data blocks";
            this.chkDisplayData.UseVisualStyleBackColor = true;
            this.chkDisplayData.CheckedChanged += new System.EventHandler(this.chkDisplayData_CheckedChanged);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.Location = new System.Drawing.Point(654, 432);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 9;
            this.btnStart.Text = "&Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(816, 432);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // skyPanel
            // 
            this.skyPanel.AllowDrop = true;
            this.skyPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.skyPanel.BackColor = System.Drawing.Color.SkyBlue;
            this.skyPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.skyPanel.DrawDataBlocks = false;
            this.skyPanel.Location = new System.Drawing.Point(13, 77);
            this.skyPanel.Name = "skyPanel";
            this.skyPanel.Size = new System.Drawing.Size(878, 349);
            this.skyPanel.TabIndex = 13;
            this.skyPanel.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(this.mwayPanel_PropertyChanged);
            // 
            // planeSource1
            // 
            this.planeSource1.BackColor = System.Drawing.Color.Black;
            this.planeSource1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("planeSource1.BackgroundImage")));
            this.planeSource1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.planeSource1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.planeSource1.Location = new System.Drawing.Point(13, 7);
            this.planeSource1.Name = "planeSource1";
            this.planeSource1.Size = new System.Drawing.Size(63, 26);
            this.planeSource1.TabIndex = 12;
            // 
            // btnDependantPlane
            // 
            this.btnDependantPlane.Location = new System.Drawing.Point(83, 7);
            this.btnDependantPlane.Name = "btnDependantPlane";
            this.btnDependantPlane.Size = new System.Drawing.Size(75, 64);
            this.btnDependantPlane.TabIndex = 14;
            this.btnDependantPlane.Text = "Create Dependant Plane";
            this.btnDependantPlane.UseVisualStyleBackColor = true;
            this.btnDependantPlane.Click += new System.EventHandler(this.btnDependantPlane_Click);
            // 
            // btnIndependantPlane
            // 
            this.btnIndependantPlane.Location = new System.Drawing.Point(165, 7);
            this.btnIndependantPlane.Name = "btnIndependantPlane";
            this.btnIndependantPlane.Size = new System.Drawing.Size(75, 64);
            this.btnIndependantPlane.TabIndex = 15;
            this.btnIndependantPlane.Text = "Create Independant Plane";
            this.btnIndependantPlane.UseVisualStyleBackColor = true;
            this.btnIndependantPlane.Click += new System.EventHandler(this.btnIndependantPlane_Click);
            // 
            // btnEventDrivenPlane
            // 
            this.btnEventDrivenPlane.Location = new System.Drawing.Point(247, 7);
            this.btnEventDrivenPlane.Name = "btnEventDrivenPlane";
            this.btnEventDrivenPlane.Size = new System.Drawing.Size(75, 64);
            this.btnEventDrivenPlane.TabIndex = 16;
            this.btnEventDrivenPlane.Text = "Create Event Driven Plane";
            this.btnEventDrivenPlane.UseVisualStyleBackColor = true;
            this.btnEventDrivenPlane.Click += new System.EventHandler(this.btnEventDrivenPlane_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(903, 465);
            this.Controls.Add(this.btnEventDrivenPlane);
            this.Controls.Add(this.btnIndependantPlane);
            this.Controls.Add(this.btnDependantPlane);
            this.Controls.Add(this.skyPanel);
            this.Controls.Add(this.planeSource1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.chkDisplayData);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Plane Simulator";
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		internal System.Windows.Forms.Button btnReset;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.CheckBox chkDisplayData;
		internal System.Windows.Forms.Button btnStart;
		internal System.Windows.Forms.Button btnExit;
		private PlaneSimulator.Controls.PlaneSource planeSource1;
        private PlaneSimulator.Controls.SkyPanel skyPanel;
        private System.Windows.Forms.Button btnDependantPlane;
        private System.Windows.Forms.Button btnIndependantPlane;
        private System.Windows.Forms.Button btnEventDrivenPlane;
	}
}

