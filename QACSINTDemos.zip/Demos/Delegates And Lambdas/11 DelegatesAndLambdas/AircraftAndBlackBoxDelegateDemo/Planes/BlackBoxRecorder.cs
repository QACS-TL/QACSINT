﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Planes
{
    public class BlackBoxRecorder
    {
        private void RecordAltitude(int altitude)
        {
            Console.WriteLine("Aircraft altitude has changed to: " + altitude);
        }

        public BlackBoxRecorder(Plane plane)
        {
            if (plane != null)
            {
                AltitudeChangedDelegate altitudeChangedDelegate = new AltitudeChangedDelegate(this.RecordAltitude);
                plane.TrackSubscriber(altitudeChangedDelegate);
            }
        }

        public BlackBoxRecorder()
        {

        }

        public AltitudeChangedDelegate AltitudeChangedRecorder
        {
            get
            {
                return new AltitudeChangedDelegate(RecordAltitude);
            }
        }

        public AltitudeChangedEventHandler AltitudeChangedHandler
        {
            get
            {
                return new AltitudeChangedEventHandler(RecordAltitude);
            }
        }

        private void RecordAltitude(object sender, AltitudeChangedEventArgs e)
        {
            Console.WriteLine(string.Format("Aircraft {0}'s altitude has changed to: {1}", (Plane)sender, e.Altitude));
        }


    }
}
