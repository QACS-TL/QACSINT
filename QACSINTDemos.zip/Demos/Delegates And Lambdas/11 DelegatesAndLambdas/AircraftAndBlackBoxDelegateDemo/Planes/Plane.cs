using System;
using System.Collections.Generic;
using System.Text;

namespace Planes {
    public class Plane
    {

#region Properties
        private string name;
        public string Name
        {
            get
            {
                return name;
            }
        }

        public int Speed
        {
            get;
            set;
        }
        public int Position
        {
            get;
            set;
        }

        private int altitude = 0;
        public int Altitude
        {
            get
            {
                return altitude;
            }
            set
            {
                if (value < 0)
                {
                    altitude = 0;
                }
                else
                {
                    if (value > 290)
                    {
                        altitude = 290;
                    }
                    else
                    {
                        altitude = value;
                    }
                }
                Broadcast(altitude);
                OnBroadCast(new AltitudeChangedEventArgs(altitude));
            }
        }

#endregion

#region Constructors

        public Plane(int speed, int position, int altitude, string name) {
            Speed = speed;
            Position = position;
            Altitude = altitude;
            this.name = name;

        }

        public Plane(int speed, string name) : this(speed, 20, 0, name) { }
        public Plane(string name) : this(10, name) { }
        public Plane() : this("Jumbo") { }

#endregion

#region Methods
        public void Accelerate(int amt) {
            Speed += amt;
            if (Speed > 70)
            {
                Speed = 70;
            }
        }
        public void Brake(int amt) {
            Speed -= amt;
            if (Speed < 0)
            {
                Speed = 0;
            }
        }

        public void Ascend(int amt)
        {
            Altitude += amt;
        }

        public void Descend(int amt)
        {

            Altitude -= amt;
        }

        public void Updateposition() {
            Position += Speed;
        }
        public string GetDataBlock() {
            return string.Format("{0},{1},{2},{3}", Name, Speed, Position, Altitude);
        }

        public override string ToString()
        {
            return this.Name;
        }
#endregion


        private AltitudeChangedDelegate altitudeChangedDelegate;

        public void TrackSubscriber(AltitudeChangedDelegate altitudeChangedDelegate)
        {
            this.altitudeChangedDelegate = altitudeChangedDelegate;
        }

        public event AltitudeChangedEventHandler altitudeChangedEvent;
 
        private void Broadcast(int newAltitude)
        {
            if (altitudeChangedDelegate != null)
            {
                altitudeChangedDelegate(newAltitude);
            }
        }
       
        private void OnBroadCast(AltitudeChangedEventArgs e)
        {
            if (altitudeChangedEvent != null)
            {
                altitudeChangedEvent(this, e);
            }
        }
    }
}
