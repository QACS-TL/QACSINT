﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BuggyCapturedVariables
{
    class Program
    {
        static void Main(string[] args)
        {
            Buggy(10);

            Console.WriteLine();

            Fixed(10);

            Console.ReadLine();
        }

        private static void Buggy(int max)
        {
            List<Action> actions = new List<Action>();

            for (int i = 0; i < max; i++)
            {
                actions.Add(() => Console.WriteLine(i));
            }

            foreach (Action a in actions)
            {
                a();
            }
        }
        private static void Fixed(int max)
        {
            List<Action> actions = new List<Action>();

            for (int i = 0; i < max; i++)
            {
                int copy = i;
                actions.Add(() => Console.WriteLine(copy));
            }

            foreach (Action a in actions)
            {
                a();
            }
        }

    }
}
