﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccounts
{
    public class Account
    {
        //Removed as per Part 4.
        //protected ActivityLogger logger = new ActivityLogger();

        protected ILogger logger = null;

        public Account():this(0)
        {

        }

        public Account(decimal balance):this(balance, new ActivityLogger())
        {

        }

        public Account(decimal balance, ILogger logger)
        {
            Balance = balance;
            this.logger = logger;
        }

        public decimal Balance { get; set; }
        public virtual void Withdraw (decimal amount)
        {
            Balance -= amount;
            logger.Log("Withdaw", $"£{amount} successfully withdrawn");
        }
        
        public void Deposit(decimal amount)
        {
            Balance += amount;
            logger.Log("Deposit", $"£{amount} successfully deposited");
        }

        
        
      
    }
}