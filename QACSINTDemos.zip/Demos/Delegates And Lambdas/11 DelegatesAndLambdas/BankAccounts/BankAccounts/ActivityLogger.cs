﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccounts
{
    public class ActivityLogger: ILogger
    {
        public void Log(string category, string message)
        {
            Console.WriteLine("Category: {0} Message: {1}",category, message);
        }
    }
}
