﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BankAccounts
{
    public class CurrentAccount: Account
    {
        public CurrentAccount(): this(0,0)
        {

        }
        public CurrentAccount(decimal balance, decimal overdraftLimit): this (balance, overdraftLimit, new ActivityLogger())
        {

        }

        public CurrentAccount(decimal balance, decimal overdraftLimit, ILogger logger): base(balance, logger)
        {
            OverdraftLimit = overdraftLimit;
        }

        public decimal OverdraftLimit { get; set; }

        public override void Withdraw(decimal amount)
        {
            if(Balance - amount < (0 - OverdraftLimit))
            {
                logger.Log("Withdaw", $"Failed to withdraw £{amount}");
                return;
            }
            base.Withdraw(amount);
        }
        
    }
    
}
