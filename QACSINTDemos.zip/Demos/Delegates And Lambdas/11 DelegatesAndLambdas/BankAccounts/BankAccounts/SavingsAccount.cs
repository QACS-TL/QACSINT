﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccounts
{
    public class SavingsAccount : Account
    {

        public SavingsAccount() : this(0)
        {
        }

        public SavingsAccount(decimal balance): this (balance, new ActivityLogger())
        {
        }

        public SavingsAccount(decimal balance, ILogger logger): base(balance, logger)
        {
        }

        public override void Withdraw(decimal amount)
        {
            if (Balance - amount < 0)
            {
                logger.Log("Withdraw", $"Failed to withdraw £{amount}");
                return;
            }
            base.Withdraw(amount);
        }

        public void ApplyInterest()
        {
            int months = 12;
            decimal rate = 0.5m;
            decimal interest = Balance * rate * months / 100;
            logger.Log("Interest Calculated", interest.ToString());

            Deposit(interest);
        }

        //Using a delegate
        public void ApplyInterest(Func<decimal, int, decimal, decimal> callBack)
        {
            int months = 12;
            decimal rate = 0.5m;
            decimal interest = callBack(Balance, months, rate);
            logger.Log("Interest Calculated", interest.ToString());

            Deposit(interest);
        }
    }
}
