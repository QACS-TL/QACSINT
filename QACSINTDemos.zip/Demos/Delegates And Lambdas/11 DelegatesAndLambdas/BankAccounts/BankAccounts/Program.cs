﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccounts
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Account account = new Account();
            //inital account, funds deposited and withdrawn
            account.Deposit(100.80m);
            account.Withdraw(60.80m);
            Console.WriteLine("Account Balance:£{0}", account.Balance);

            //create new account using constructor and injecting ILogger object, funds deposited and withdrawn
            account = new Account(200.00m, new ActivityLogger());
            account.Deposit(100.80m);
            account.Withdraw(60.80m);
            Console.WriteLine("Account Balance:£{0}", account.Balance);

            //Current account with £100 Overdaft
            CurrentAccount currentAccount = new CurrentAccount();
            currentAccount.OverdraftLimit = 100;
            //Withdrawing a value that takes the balance below 0 but above overdraft limit
            currentAccount.Withdraw(50);
            //Withdrawing a value that takes the balance above overdraft limit
            currentAccount.Withdraw(51);
            Console.WriteLine("Current Account Balance:£{0}", currentAccount.Balance);

            //Create new current acccount using constructor and injecting ILogger object
            currentAccount = new CurrentAccount(200.00m, 100.00m, new ActivityLogger());
            //Withdrawing a value that takes the balance below 0 but above overdraft limit
            currentAccount.Withdraw(150.00m);
            //Withdrawing a value that takes the balance above overdraft limit
            currentAccount.Withdraw(51.00m);
            Console.WriteLine("Current Account Balance:£{0}", currentAccount.Balance);

            //Savings account with no overdraft
            SavingsAccount savingsAccount = new SavingsAccount();
            //withdrawing any value with no other depoists will fail
            savingsAccount.Withdraw(50.00m);
            Console.WriteLine("Savings Account Balance:£{0}", savingsAccount.Balance);

            //Create new savings acccount using constructor and injecting ILogger objec
            savingsAccount = new SavingsAccount(150m, new ActivityLogger());
            savingsAccount.Withdraw(120.00m);
            //withdrawing any value with no other deposits will fail
            savingsAccount.Withdraw(50.00m);
            Console.WriteLine("Savings Account Balance:£{0}", savingsAccount.Balance);
            savingsAccount.ApplyInterest();
            Console.WriteLine("Savings Account Balance:£{0}", savingsAccount.Balance);

            //Apply interest using delegate
            savingsAccount.ApplyInterest(CalculateInterest);
            Console.WriteLine("Savings Account Balance:£{0}", savingsAccount.Balance);

            //Apply interest using anonymous delegate
            savingsAccount.ApplyInterest(delegate(decimal balance, int months, decimal rate) {
                return balance * rate * ((decimal)months) / 100;

            });
            Console.WriteLine("Savings Account Balance:£{0}", savingsAccount.Balance);

            //Apply interest using lambda and anonymous delegate
            savingsAccount.ApplyInterest((balance, rate, months) => {
                return balance * rate * ((decimal)months) / 100;
            });
            Console.WriteLine("Savings Account Balance:£{0}", savingsAccount.Balance);

            Console.ReadLine();
        }

        static decimal CalculateInterest(decimal balance, int months, decimal rate)
        {
            return balance * rate * ((decimal) months)/100;
        }
    }
}
