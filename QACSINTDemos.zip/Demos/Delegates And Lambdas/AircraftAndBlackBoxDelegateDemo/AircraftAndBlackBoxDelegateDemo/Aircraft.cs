﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AircraftAndBlackBoxDelegateDemo
{
    public class Aircraft
    {
        private AltitudeChangedDelegate altitudeChanged;
        private int mAltitude;

        #region "Constructors, properties and overrides"
        private string mName;

        public Aircraft()
        {
            mName = "Jumbo";
        }

        public Aircraft(string name)
        {
            mName = name;
        }

        public string Name
        {
            get { return mName; }
        }

        public override string ToString()
        {
            return this.Name;
        }
        #endregion

        #region "Pure Delegate"
        public int Altitude
        {
            get { return mAltitude; }
            set
            {
                if (value != mAltitude)
                {
                    mAltitude = value;
                    Broadcast(Altitude);
                    OnBroadCast(new AltitudeChangedEventArgs(Altitude));
                }
            }
        }

        public void TrackSubscriber(AltitudeChangedDelegate ac)
        {
            altitudeChanged = ac;
        }

        private void Broadcast(int amt)
        {
            if (altitudeChanged != null)
            {
                // syntactic shortcut for … 
                altitudeChanged(amt);
            }
            //altitudeChanged.Invoke(amt);
        }
        #endregion

        #region "Event Model"

        public event AltitudeChangedEventHandler altitudeChangedEvent;
        //public event EventHandler<AltitudeChangedEventArgs> altitudeChangedEvent;
        //Event
        private void OnBroadCast(AltitudeChangedEventArgs e)
        {
            if (altitudeChangedEvent != null)
            {
                altitudeChangedEvent(this, e);
            }
        }
        #endregion

    }
}
