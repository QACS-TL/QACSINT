﻿namespace AircraftAndBlackBoxDelegateDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nudUseEventsAltitude = new System.Windows.Forms.NumericUpDown();
            this.btnUseEventsAdjustHeight = new System.Windows.Forms.Button();
            this.btnUseEvents = new System.Windows.Forms.Button();
            this.nudIndependantPlaneAltitude = new System.Windows.Forms.NumericUpDown();
            this.btnAdjustIndependantPlaneHeight = new System.Windows.Forms.Button();
            this.btnIndependantPlane = new System.Windows.Forms.Button();
            this.nudDependantPlaneAltitude = new System.Windows.Forms.NumericUpDown();
            this.btnAdjustDependantPlaneHeight = new System.Windows.Forms.Button();
            this.btnCreateDependantPlane = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudUseEventsAltitude)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudIndependantPlaneAltitude)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDependantPlaneAltitude)).BeginInit();
            this.SuspendLayout();
            // 
            // nudUseEventsAltitude
            // 
            this.nudUseEventsAltitude.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudUseEventsAltitude.Location = new System.Drawing.Point(226, 222);
            this.nudUseEventsAltitude.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.nudUseEventsAltitude.Name = "nudUseEventsAltitude";
            this.nudUseEventsAltitude.Size = new System.Drawing.Size(83, 20);
            this.nudUseEventsAltitude.TabIndex = 17;
            this.nudUseEventsAltitude.ThousandsSeparator = true;
            // 
            // btnUseEventsAdjustHeight
            // 
            this.btnUseEventsAdjustHeight.Location = new System.Drawing.Point(13, 222);
            this.btnUseEventsAdjustHeight.Name = "btnUseEventsAdjustHeight";
            this.btnUseEventsAdjustHeight.Size = new System.Drawing.Size(175, 23);
            this.btnUseEventsAdjustHeight.TabIndex = 16;
            this.btnUseEventsAdjustHeight.Text = "Adjust  Plane Height";
            this.btnUseEventsAdjustHeight.UseVisualStyleBackColor = true;
            this.btnUseEventsAdjustHeight.Click += new System.EventHandler(this.btnUseEventsAdjustHeight_Click);
            // 
            // btnUseEvents
            // 
            this.btnUseEvents.Location = new System.Drawing.Point(13, 193);
            this.btnUseEvents.Name = "btnUseEvents";
            this.btnUseEvents.Size = new System.Drawing.Size(175, 23);
            this.btnUseEvents.TabIndex = 15;
            this.btnUseEvents.Text = "Use Events";
            this.btnUseEvents.UseVisualStyleBackColor = true;
            this.btnUseEvents.Click += new System.EventHandler(this.btnUseEvents_Click);
            // 
            // nudIndependantPlaneAltitude
            // 
            this.nudIndependantPlaneAltitude.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudIndependantPlaneAltitude.Location = new System.Drawing.Point(225, 140);
            this.nudIndependantPlaneAltitude.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.nudIndependantPlaneAltitude.Name = "nudIndependantPlaneAltitude";
            this.nudIndependantPlaneAltitude.Size = new System.Drawing.Size(83, 20);
            this.nudIndependantPlaneAltitude.TabIndex = 14;
            this.nudIndependantPlaneAltitude.ThousandsSeparator = true;
            // 
            // btnAdjustIndependantPlaneHeight
            // 
            this.btnAdjustIndependantPlaneHeight.Location = new System.Drawing.Point(12, 140);
            this.btnAdjustIndependantPlaneHeight.Name = "btnAdjustIndependantPlaneHeight";
            this.btnAdjustIndependantPlaneHeight.Size = new System.Drawing.Size(176, 23);
            this.btnAdjustIndependantPlaneHeight.TabIndex = 13;
            this.btnAdjustIndependantPlaneHeight.Text = "Adjust Independant Plane Height";
            this.btnAdjustIndependantPlaneHeight.UseVisualStyleBackColor = true;
            this.btnAdjustIndependantPlaneHeight.Click += new System.EventHandler(this.btnAdjustIndependantPlaneHeight_Click);
            // 
            // btnIndependantPlane
            // 
            this.btnIndependantPlane.Location = new System.Drawing.Point(12, 111);
            this.btnIndependantPlane.Name = "btnIndependantPlane";
            this.btnIndependantPlane.Size = new System.Drawing.Size(176, 23);
            this.btnIndependantPlane.TabIndex = 12;
            this.btnIndependantPlane.Text = "Create Independant Plane";
            this.btnIndependantPlane.UseVisualStyleBackColor = true;
            this.btnIndependantPlane.Click += new System.EventHandler(this.btnIndependantPlane_Click);
            // 
            // nudDependantPlaneAltitude
            // 
            this.nudDependantPlaneAltitude.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudDependantPlaneAltitude.Location = new System.Drawing.Point(225, 41);
            this.nudDependantPlaneAltitude.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.nudDependantPlaneAltitude.Name = "nudDependantPlaneAltitude";
            this.nudDependantPlaneAltitude.Size = new System.Drawing.Size(83, 20);
            this.nudDependantPlaneAltitude.TabIndex = 11;
            this.nudDependantPlaneAltitude.ThousandsSeparator = true;
            // 
            // btnAdjustDependantPlaneHeight
            // 
            this.btnAdjustDependantPlaneHeight.Location = new System.Drawing.Point(12, 41);
            this.btnAdjustDependantPlaneHeight.Name = "btnAdjustDependantPlaneHeight";
            this.btnAdjustDependantPlaneHeight.Size = new System.Drawing.Size(176, 23);
            this.btnAdjustDependantPlaneHeight.TabIndex = 10;
            this.btnAdjustDependantPlaneHeight.Text = "Adjust Dependant Plane Height";
            this.btnAdjustDependantPlaneHeight.UseVisualStyleBackColor = true;
            this.btnAdjustDependantPlaneHeight.Click += new System.EventHandler(this.btnAdjustDependantPlaneHeight_Click);
            // 
            // btnCreateDependantPlane
            // 
            this.btnCreateDependantPlane.Location = new System.Drawing.Point(12, 12);
            this.btnCreateDependantPlane.Name = "btnCreateDependantPlane";
            this.btnCreateDependantPlane.Size = new System.Drawing.Size(135, 23);
            this.btnCreateDependantPlane.TabIndex = 9;
            this.btnCreateDependantPlane.Text = "Create Dependant Plane";
            this.btnCreateDependantPlane.UseVisualStyleBackColor = true;
            this.btnCreateDependantPlane.Click += new System.EventHandler(this.btnCreateDependantPlane_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 262);
            this.Controls.Add(this.nudUseEventsAltitude);
            this.Controls.Add(this.btnUseEventsAdjustHeight);
            this.Controls.Add(this.btnUseEvents);
            this.Controls.Add(this.nudIndependantPlaneAltitude);
            this.Controls.Add(this.btnAdjustIndependantPlaneHeight);
            this.Controls.Add(this.btnIndependantPlane);
            this.Controls.Add(this.nudDependantPlaneAltitude);
            this.Controls.Add(this.btnAdjustDependantPlaneHeight);
            this.Controls.Add(this.btnCreateDependantPlane);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudUseEventsAltitude)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudIndependantPlaneAltitude)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDependantPlaneAltitude)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.NumericUpDown nudUseEventsAltitude;
        internal System.Windows.Forms.Button btnUseEventsAdjustHeight;
        internal System.Windows.Forms.Button btnUseEvents;
        internal System.Windows.Forms.NumericUpDown nudIndependantPlaneAltitude;
        internal System.Windows.Forms.Button btnAdjustIndependantPlaneHeight;
        internal System.Windows.Forms.Button btnIndependantPlane;
        internal System.Windows.Forms.NumericUpDown nudDependantPlaneAltitude;
        internal System.Windows.Forms.Button btnAdjustDependantPlaneHeight;
        internal System.Windows.Forms.Button btnCreateDependantPlane;
    }
}

