﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AircraftAndBlackBoxDelegateDemo
{
    public partial class Form1 : Form
    {
        private Aircraft dependantPlane;
        private Aircraft independantPlane;
        private Aircraft useEventIndependantPlane;
        private BlackBoxRecorder dependantPlaneRecorder;
        private BlackBoxRecorder independantPlaneRecorder;
        private BlackBoxRecorder useEventIndependantPlaneRecorder;
        
        public Form1()
        {
            InitializeComponent();
        }


        private void btnCreateDependantPlane_Click(System.Object sender, System.EventArgs e)
        {
            dependantPlane = new Aircraft("DA1234");
            dependantPlaneRecorder = new BlackBoxRecorder(dependantPlane);
        }

        private void btnAdjustDependantPlaneHeight_Click(System.Object sender, System.EventArgs e)
        {
            dependantPlane.Altitude = Convert.ToInt32(nudDependantPlaneAltitude.Value);
        }


        private void btnIndependantPlane_Click(System.Object sender, System.EventArgs e)
        {
            independantPlane = new Aircraft("QJ456");
            independantPlaneRecorder = new BlackBoxRecorder();
            independantPlane.TrackSubscriber(independantPlaneRecorder.AltitudeChangedRecorder);
        }

        private void btnAdjustIndependantPlaneHeight_Click(System.Object sender, System.EventArgs e)
        {
            independantPlane.Altitude = Convert.ToInt32(nudIndependantPlaneAltitude.Value);
        }


        private void btnUseEvents_Click(System.Object sender, System.EventArgs e)
        {
            useEventIndependantPlane = new Aircraft("BD789");
            useEventIndependantPlaneRecorder = new BlackBoxRecorder();
            useEventIndependantPlane.altitudeChangedEvent += useEventIndependantPlaneRecorder.AltitudeChangedEH;
        }

        private void btnUseEventsAdjustHeight_Click(System.Object sender, System.EventArgs e)
        {
            useEventIndependantPlane.Altitude = Convert.ToInt32(nudUseEventsAltitude.Value);
        }
    }
}
