﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AircraftAndBlackBoxDelegateDemo
{
    public class BlackBoxRecorder
    {
        private Aircraft mPlane = null;

        #region "Properties etc.."
        public Aircraft Plane
        {
            get { return mPlane; }
        }
        #endregion

        #region "Dependant Plane"
        //used by dependant plane
        public BlackBoxRecorder(Aircraft plane)
        {
            if (plane != null)
            {
                mPlane = plane;
                AltitudeChangedDelegate aceh = new AltitudeChangedDelegate(this.RecordAltitude);
                plane.TrackSubscriber(aceh);
            }
        }
        #endregion

        private void RecordAltitude(int alt)
        {
            MessageBox.Show("Aircraft altitude has changed to: " + alt);
        }

        #region "Independant Plane"
        //used by independant plane
        public BlackBoxRecorder()
        {

        }

        //Used by independant plane
        public AltitudeChangedDelegate AltitudeChangedRecorder
        {
            get { return new AltitudeChangedDelegate(RecordAltitude); }
        }
        #endregion

        #region "Event Model"
        //Used by use events independant plane
        public AltitudeChangedEventHandler AltitudeChangedEH
        {
            //public EventHandler(Of AltitudeChangedEventArgs) AltitudeChangedEH()
            get { return RecordAltitude; }
        }

        private void RecordAltitude(object sender, AltitudeChangedEventArgs e)
        {
            MessageBox.Show(string.Format("Aircraft {0}'s altitude has changed to: {1}", (Aircraft)sender, e.Altitude));
        }
        #endregion
    }
}
