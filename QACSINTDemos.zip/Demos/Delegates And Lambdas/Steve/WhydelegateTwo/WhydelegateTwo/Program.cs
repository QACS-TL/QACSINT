﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhydelegateTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            Benchmark(20, () =>
            {
                var xs = Enumerable.Range(0, 100000).ToList();
            });
            //Benchmark(5, SomeExpensiveFunction);
        }

        public static void Benchmark(int times, Action func)
        {
            var watch = new System.Diagnostics.Stopwatch();
            double totalTime = 0.0;

            for (int i = 0; i < times; i++)
            {
                watch.Start();
                //Foo(); // Execute our injected function
                func.Invoke();
                watch.Stop();

                totalTime += watch.ElapsedMilliseconds;
                watch.Reset();
            }

            double averageTime = totalTime / times;
            Console.WriteLine("{0}ms", totalTime);
        }

        public static void Foo()
        {
            for (int j = 0; j < 1000; j++)
            {
                for (int i = 0; i < 100000; i++)
                {
                }
            }
        }
    }
}
