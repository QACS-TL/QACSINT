﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhyDelegate {



    class Program {

        delegate bool Check(int n);
        //Func<bool, int> Check;

        static void Main(string[] args)
        {
            // Not great way
            IEnumerable<int> lessthanfive = GetAllNumbersLessThanFive(
                new[] {2, 4, 6, 7, 1, 0, 10, 20});
            foreach(int num in lessthanfive)
                Console.WriteLine(num);

            IEnumerable<int> result = GetAllNumbersLessThan(
                new[] { 2, 6, 1, 4, 10, 15, 11, 14, 20 }, LessThanFive);
            Console.WriteLine("Numbers less than 5:");
            foreach(int number in result)
                Console.WriteLine(number);

            result = GetAllNumbersLessThan(
                new[] { 2, 6, 1, 4, 10, 15, 11, 14, 20 }, LessThanTen);
            Console.WriteLine("Numbers less than 10");
            foreach (int number in result)
                Console.WriteLine(number);
        }

        static bool LessThanFive(int n) {
            return n < 5;
        }
        static bool LessThanTen(int n) {
            return n < 10;
        }

        static IEnumerable<int> GetAllNumbersLessThan(IEnumerable<int> numbers, Check c) {
            foreach (int number in numbers)
                if (c(number))
                    yield return number;
        }
        // Not great way
        static IEnumerable<int> GetAllNumbersLessThanFive(IEnumerable<int> numbers) {
            foreach (int number in numbers)
                if (number < 5)
                    yield return number;
        }
        // What if wanted numbers less than ten
        static IEnumerable<int> GetAllNumbersLessThanTen(IEnumerable<int> numbers) {
            foreach (int number in numbers)
                if (number < 10)
                    yield return number;
        }
    }
}
