﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncActionDelegate {
    class Program {

        delegate int AddDelegate(int x, int y);
        delegate void FooDelegate();
        delegate void AgeNameDelegate(int age, string name);
        
        static void Main(string[] args) {

            Action<int, int> addPtr = Add;
            addPtr(10, 20);
            Action fAction = FooBar;
            Action<int, string> agenAction = AgeName;

            Func<int, int, int> fptr = AddFunc;

            Predicate<int> predPtr;

            FooDelegate foo = FooBar;
            foo();
            AddDelegate add = AddFunc;
            Console.WriteLine(add(20, 30));
            AgeNameDelegate ageName = AgeName;
            ageName(23, "Ellen");
        }
        static void Add(int x, int y) {
            Console.WriteLine(x + y);
        }
        static int AddFunc(int x, int y) {
            return x + y;
        }
        static int MyAdd(int x, int y) {
            return x + y;
        }
        static void FooBar() {
            Console.WriteLine("Called from function pointer");
        }
        static void AgeName(int age, string name) {
            Console.WriteLine($"Hello {name}, you are {age} years old");
        }
    }
}
