using System;

namespace Interfaces {

    public interface IInsurable {
        string GetPremium();
        string Expires();
    }

}
