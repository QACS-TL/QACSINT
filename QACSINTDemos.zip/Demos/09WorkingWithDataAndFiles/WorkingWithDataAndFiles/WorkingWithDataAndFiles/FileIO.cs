﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkingWithDataAndFiles
{
    internal class FileIO
    {
        public static void DoingIO() { 
            using (StreamReader rdr = new StreamReader("in.txt")) { 
                using (StreamWriter wtr = new StreamWriter("out.txt")) { 
                    string line; 
                    while ((line = rdr.ReadLine()) != null) { 
                        wtr.WriteLine(line); 
                    } 
                } 
            } 
        }
    }
}
