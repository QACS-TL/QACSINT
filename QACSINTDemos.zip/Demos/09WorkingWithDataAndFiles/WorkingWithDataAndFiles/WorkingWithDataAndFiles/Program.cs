﻿using CsvHelper;
using Newtonsoft.Json;
using System.Formats.Asn1;
using System.Globalization;
using System.Text;
using WorkingWithDataAndFiles;

// Page 6 - Getting FIle Information
FileInfo mf = new FileInfo(@"C:\Labs\WarAndPeace.txt"); if (mf.Exists)
{
    Console.WriteLine("Filename: {0}", mf.Name);
    Console.WriteLine("Path: {0}", mf.FullName);
    Console.WriteLine("Length: {0}", mf.Length.ToString());
}

//FileInfo fileToCopy = new FileInfo(@"C:\Labs\WarAndPeace.txt");
//fileToCopy.CopyTo(@"C:\Labs\copy of WarAndPeace.txt");

// Page 7 - DirectoryInfo
DirectoryInfo di = new DirectoryInfo(@"C:\Windows");
Console.WriteLine("Directory: {0}", di.FullName);
foreach (FileInfo fi in di.GetFiles())
{
    Console.WriteLine("File: {0}", fi.Name);
}

// Page 8 - The Path Class
string p = @"C:\Labs\WarAndPeace.txt";
Console.WriteLine("Extension: {0}", Path.GetExtension(p));
string renamedFile = Path.ChangeExtension(p, "bak"); // Note, does not actually change the file name
Console.WriteLine($"Extension: {renamedFile}");
Console.WriteLine($"Extension: {Path.GetExtension(p)}" );

// Page 11 - The using Statement
//FileIO.DoingIO();

// Page 12 - The File Class
using (FileStream fs = File.Open(@"in.txt", FileMode.Open, FileAccess.Read)) { 
    using (StreamReader sr = new StreamReader(fs)) { 
        Console.Write(sr.ReadToEnd()); 
    } 
}

using (StreamReader sr = File.OpenText(@"in.txt")) { 
    Console.Write(sr.ReadToEnd()); 
}

// Page 14 - Serializing and Deserializing JSON
PersonFilms personFilms = new PersonFilms
{
    Name = "Andrew",
    Age = 50,
    FavouriteFilms = new List<string>() {
                    "Toy Story",
                    "Toy Story 2",
                    "Aliens"
    }
};

string pfs = JsonConvert.SerializeObject(personFilms, Formatting.Indented);
Console.WriteLine(pfs);
PersonFilms pfs2 = JsonConvert.DeserializeObject<PersonFilms>(pfs);
Console.WriteLine(pfs2.Name);
Console.WriteLine(pfs2.Age);
pfs2.FavouriteFilms.ForEach(f => Console.WriteLine(f));

// Page 15 - JSON Anonymous Objects
var obj1 = new
{
    name = "Maria",
    age = 39,
    favouriteFilms = new List<string>() {
                    "Love Story",
                    "Inception",
                    "It's a Wonderful Life"
    }
};
string json1 = JsonConvert.SerializeObject(obj1, Newtonsoft.Json.Formatting.Indented);
File.WriteAllText("file1.json", json1);

// Reading JSON into an anonymous, dynamic object then picking out elements
string s1 = File.ReadAllText("file1.json");
dynamic obj2 = JsonConvert.DeserializeObject(s1);
Console.WriteLine(obj2.name);
Console.WriteLine(obj2.age);
Console.WriteLine(obj2.favouriteFilms);

// Page 17 - Reading a CSV File
// Reading and displaying a list of people from a CSV file
using (var sr = new StreamReader("movies.csv"))

//InvariantCulture - I don't care, I don't want culture involved in the first place.
using (var reader = new CsvReader(sr, CultureInfo.InvariantCulture))
{
    var list = reader.GetRecords<Movie>().ToList();

    //list.ForEach(m => Console.WriteLine($"{m.Title} is {m.ReleaseYear}"));
    foreach (Movie m in list)
    {
        Console.WriteLine($"{m.Title} was released in {m.ReleaseYear}");
    }
}

// Page 18 - Reading a CSV File into a Dynamic Class
// Reading records into dynamic class (NB: every property value will be a string!)
using (var sr = new StreamReader("movies.csv"))
using (var reader = new CsvReader(sr, CultureInfo.InvariantCulture))
{
    var list = reader.GetRecords<dynamic>().ToList();

    foreach (var m in list)
    {
        Console.WriteLine($"{m.Title} was directed by {m.Director}");
    }
}

// Page 19 - Writing to a CSV File
// Writing a list to a CSV file
var more_movies = new Movie[] {
  new Movie { Title = "2001: A Space Odyssey",
      ReleaseYear = 1968, Director="Stanley Kubrick", GrossRevenue=146 },
  new Movie { Title = "Dark Star",
      ReleaseYear = 1975, Director="John Carpenter", GrossRevenue=null },
  new Movie { Title = "The Martian",
      ReleaseYear = 2015, Director="Ridley Scott", GrossRevenue=631 }
};

using (var sw = new StreamWriter("updated_movies.csv")) // overwrite any existing data
using (var writer = new CsvWriter(sw, CultureInfo.InvariantCulture))
{
    writer.WriteRecords(more_movies);
}

// Append to end of existing file and suppress header row
using (var sw = new StreamWriter("updated_movies.csv", true)) 
using (var writer = new CsvWriter(sw, CultureInfo.InvariantCulture))
{
    foreach(var movie in more_movies)
    {
        writer.WriteRecord(movie);
        writer.NextRecord(); // Adds a new line (CRLF) to file
    }

}




