﻿using EF1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System.Data;
using System.Runtime.CompilerServices;

using (NorthwindContext con = new ())
{
    var customers = con.Customers.Where(c => c.CompanyName.StartsWith("A"));
    foreach (var customer in customers)
    {
        Console.WriteLine($"Company Name: {customer.CompanyName}, Contact Name: {customer.ContactName}, Phone: {customer.Phone}");
    }
}

Console.WriteLine("***************************************");
using (NorthwindContext con = new NorthwindContext())
{
    Customer cust = new Customer()
    {
        CustomerId = "AARDV",
        CompanyName = "Aardarks R Us",
        ContactName = "Mr Aardvark",
        Phone = "0123 456789"
    };
    con.Customers.Add(cust);
    con.SaveChanges();
}

Console.WriteLine("***************************************");
using (NorthwindContext con = new NorthwindContext())
{
    var customers = con.Customers.Where(c => c.CompanyName.StartsWith("Aa"));
    foreach (var customer in customers)
    {
        Console.WriteLine($"Company Name: {customer.CompanyName}, Contact Name: {customer.ContactName}, Phone: {customer.Phone}");
    }
}

Console.WriteLine("***************************************");
using (NorthwindContext con = new NorthwindContext())
{
    Customer cust = con.Customers.SingleOrDefault(c => c.CustomerId == "AARDV");
    if (cust != null)
    {
        cust.ContactName = "Ms Abigail Aaardvark";
        con.SaveChanges();
    }
}

Console.WriteLine("***************************************");
using (NorthwindContext con = new NorthwindContext())
{
    var customers = con.Customers.Where(c => c.CompanyName.StartsWith("Aa"));
    foreach (var customer in customers)
    {
        Console.WriteLine($"Company Name: {customer.CompanyName}, Contact Name: {customer.ContactName}, Phone: {customer.Phone}");
    }
}

Console.WriteLine("***************************************");
using (NorthwindContext con = new NorthwindContext())
{
    Customer cust = new Customer()
    {
        CustomerId = "AARDV",
        CompanyName = "Aardarks R Us",
        ContactName = "Mr Aardvark",
        Phone = "0123 456789"
    };
    con.Customers.Remove(cust);
    con.SaveChanges();
}

Console.WriteLine("***************************************");
using (NorthwindContext con = new NorthwindContext())
{
    //There should be no "Aardvarks R Us" row in the printed results
    var customers = con.Customers.Where(c => c.CompanyName.StartsWith("A"));
    foreach (var customer in customers)
    {
        Console.WriteLine($"Company Name: {customer.CompanyName}, Contact Name: {customer.ContactName}, Phone: {customer.Phone}");
    }
}
