﻿using BankAccounts;
using System.Xml.Linq;

Account account1 = new Account();
account1.Name = "Irma Person";
account1.AccountNumber = "123456";
account1.Balance = 100.00m;

Account account2 = new Account() { Name = "A. N. Other", AccountNumber = "888888", Balance =  400.00m };

account1.Credit(50.0m);
account2.Debit(50.0m);

account1.Transfer(account2, 100.00M);

//account1.Transfer("888888", 100.00M);

//Account.Transfer("123456", "888888", 100.00M);

Console.WriteLine(account1.Balance);
Console.WriteLine(account2.Balance);

List<Account> accounts = new List<Account>();
accounts.Add(account1);
accounts.Add(account2);
accounts.Add(new Account() { Name = "Hamza", AccountNumber = "444444", Balance = 150.00m });
accounts.Add(new Account() { Name = "Zoe", AccountNumber = "555555", Balance = 4.50m });

// Apply Interest or determine Overdraft Limit
foreach (Account a in accounts)
{
    Console.WriteLine($"Account Name:{a.Name}, Number: {a.AccountNumber}, Balance: {a.Balance}");
}






