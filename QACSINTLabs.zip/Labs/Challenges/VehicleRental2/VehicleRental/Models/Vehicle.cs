﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRental.Models
{
    public abstract class Vehicle: IRentable
    {
        public int Id { get; set; }
        public string Model { get; set; } = string.Empty;
        public decimal DailyRate { get; set; }
        public bool IsRented { get; set; }

        public abstract void Rent();
        public abstract void Return();

        public override string ToString() =>
            $"{GetType().Name}: {Model} (${DailyRate}/day, {(IsRented ? "Not available" : "Available")})";
    }
}
