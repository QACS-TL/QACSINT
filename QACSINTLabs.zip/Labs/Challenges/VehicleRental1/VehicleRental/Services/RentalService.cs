﻿using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
namespace VehicleRental.Services
{
    public class RentalService
    {
        private List<Vehicle> _vehicles { get; set; }

        public RentalService(List<Vehicle> vehicles) => _vehicles = vehicles;

        // Collections: materialize to List for in-memory operations if needed
        public List<Vehicle> GetAll()
        {
            return _vehicles;
        }

        public string Rent(int id)
        {
            var vehicle = FindTracked(id);

            if (vehicle.IsRented)
            {
                return "Error: Vehicle is not available.";
            }
            vehicle.Rent(); // may throw Exception
            return $"You rented {vehicle.Model}";

        }

        public string Return(int id)
        {
            var vehicle = FindTracked(id);

            if (!vehicle.IsRented)
            {
                return "Error: Vehicle is not currently rented so can't be returned.";
            }
            vehicle.Return();
            return $"{vehicle.Model} returned successfully";
        }

        private Vehicle? FindTracked(int id)
        {
            // Try cars first, then motorcycles
            Vehicle vehicle = null;
            foreach(Vehicle v in _vehicles)
            {
                if (v.Id == id)
                {
                    vehicle = v;
                    break;
                }
            }
           return vehicle;

        }
    }
}
