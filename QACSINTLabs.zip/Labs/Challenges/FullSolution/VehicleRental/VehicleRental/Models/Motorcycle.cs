﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRental.Models
{
    public class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }

        public override void Rent()
        {
            if (IsRented) throw new VehicleNotAvailableException($"{Model} is already rented.");
            IsRented = true;
        }

        public override void Return()
        {
            IsRented = false;
        }
    }
}
