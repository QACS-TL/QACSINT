﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRental.Models
{
    public class RentalDbContext : DbContext
    {
        public DbSet<Car> Cars => Set<Car>();
        public DbSet<Motorcycle> Motorcycles => Set<Motorcycle>();

        public string DbPath { get; }

        public RentalDbContext()
        {
            // SQLite file next to the executable
            var folder = AppContext.BaseDirectory;
            DbPath = Path.Combine(folder, "rental.db");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=VehicleRentalDB1;Trusted_Connection=True;Encrypt=False;AttachDbFilename=C:\QAL\QACSV7.1\New Courses\QAICS\Labs\Challenges\FullSolution\VehicleRental\VehicleRental\VehicleRentalDB1.mdf;");


        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    //Simple seeding
        //    modelBuilder.Entity<Car>().HasData(
        //        new Car { Id = 1, Model = "Toyota Corolla", DailyRate = 40m, IsRented = false, NumberOfDoors = 4 },
        //        new Car { Id = 2, Model = "Tesla Model 3", DailyRate = 85m, IsRented = false, NumberOfDoors = 4 }
        //    );

        //    modelBuilder.Entity<Motorcycle>().HasData(
        //        new Motorcycle { Id = 3, Model = "Harley Davidson", DailyRate = 55m, IsRented = false, HasSidecar = false },
        //        new Motorcycle { Id = 4, Model = "Honda Gold Wing", DailyRate = 70m, IsRented = false, HasSidecar = true }
        //    );
        //}

    }
}
