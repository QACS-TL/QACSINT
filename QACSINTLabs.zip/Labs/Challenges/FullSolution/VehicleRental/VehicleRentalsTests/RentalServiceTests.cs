﻿using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
using VehicleRental.Services;
using Xunit;

namespace VehicleRentalTests
{

        public class RentalServiceTests
        {
            private static RentalService BuildService(out RentalDbContext ctx)
            {
                var options = new DbContextOptionsBuilder<RentalDbContext>()
                    .UseInMemoryDatabase($"rental_test_{Guid.NewGuid()}")
                    .Options;

                ctx = new TestRentalDbContext(options);
                ctx.Database.EnsureCreated();
                Seed(ctx);
                return new RentalService(ctx);
            }

        private static void Seed(RentalDbContext db)
        {
            db.Cars.RemoveRange(db.Cars);
            db.Motorcycles.RemoveRange(db.Motorcycles);
            db.Cars.AddRange(
                new Car { Id = 1, Model = "Toyota Corolla T", DailyRate = 40m, NumberOfDoors = 4, IsRented = false },
                new Car { Id = 2, Model = "Tesla Model 3 T", DailyRate = 85m, NumberOfDoors = 4, IsRented = false }
            );
            db.Motorcycles.AddRange(
                new Motorcycle { Id = 3, Model = "Harley Davidson T", DailyRate = 55m, HasSidecar = false, IsRented = false },
                new Motorcycle { Id = 4, Model = "Honda Gold Wing T", DailyRate = 70m, HasSidecar = true, IsRented = true }
            );
            db.SaveChanges();
        }

        [Fact]
            public void Rent_Vehicle_ShouldMarkAsRented()
            {
                var service = BuildService(out var ctx);

                service.Rent(1);

                var car = ctx.Cars.Find(1);
                Assert.True(car!.IsRented);
            }

            [Fact]
            public void Rent_AlreadyRented_ShouldThrow()
            {
                var service = BuildService(out _);

                Assert.Throws<VehicleNotAvailableException>(() => service.Rent(5));
            }

            [Fact]
            public void Return_Vehicle_ShouldMarkAsAvailable()
            {
                var service = BuildService(out var ctx);

                service.Return(4);

                var moto = ctx.Motorcycles.Find(4);
                Assert.False(moto!.IsRented);
            }

            [Fact]
            public void FindUnderDailyRate_FiltersAndOnlyAvailable()
            {
                var service = BuildService(out _);

                var results = service.FindUnderDailyRate(60m);

                Assert.All(results, v => Assert.True(v.DailyRate <= 60m && !v.IsRented));
                Assert.Contains(results, v => v.Model == "Toyota Corolla T");
                Assert.DoesNotContain(results, v => v.Model == "Honda Gold Wing T"); // rented
            }

            // Use an in-memory context that skips SQLite config
            private class TestRentalDbContext : RentalDbContext
            {
                private readonly DbContextOptions<RentalDbContext> _options;

                public TestRentalDbContext(DbContextOptions<RentalDbContext> options)
                {
                    _options = options;
                }

                protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
                    => optionsBuilder.UseInMemoryDatabase($"ignored");
            }
        }
}
