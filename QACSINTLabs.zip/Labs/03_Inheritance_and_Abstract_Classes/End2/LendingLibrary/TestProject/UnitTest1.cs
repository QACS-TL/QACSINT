using LendingLibrary;
using System;
using Xunit;

namespace TestProject
{
    public class UnitTest1
    {
        Library library;
        Member ittzy;
        Member irma;

        public UnitTest1()
        {
            library = new Library();
            ittzy = library.Add(name: "Ittzy Child", age: 15);
            ittzy.Street = "1 the High Street";
            ittzy.City = "Buddlington";
            ittzy.OustandingFines = 25M;
            irma = library.Add(name: "Irma Adult", age: 73);
            irma.Street = "2 the High Street";
            irma.City = "Cruddlington";
            irma.OustandingFines = 2500M;
        }

        [Fact]
        public void Create()
        {
            Assert.Equal(2, library.NumberOfMembers);
            Assert.Equal(1, ittzy.MembershipNumber);
            Assert.Equal(2, irma.MembershipNumber);
        }

        [Fact]
        public void Child_Borrows_Child_Book_OK()
        {
            // a junior member (under 16) can borrow only child category books
            Book childBook = library.GetBook(101);
            Assert.True(ittzy.Borrow(childBook));
        }

        [Fact]
        public void Child_Borrows_Adult_Book_Fails()
        {
            // a junior member (under 16) can borrow only child category books
            Book adultBook = library.GetBook(100);
            Assert.False(ittzy.Borrow(adultBook));
        }

        [Fact]
        public void Adult_Can_Bottow_Any_Book()
        {
            // a junior member (under 16) can borrow only child category books
            Book adultBook = library.GetBook(100);
            Book childBook = library.GetBook(101);
            Assert.True(irma.Borrow(adultBook));
            Assert.True(irma.Borrow(childBook));
        }

        [Fact]
        public void Child_Pays_Fine_From_Cash_Fund()
        {
            ittzy.SetFineLimit(20M);
            ittzy.PayFine(7M);
            Assert.Equal(13M, ittzy.GetFineCredit());
        }

        [Fact]
        public void Adult_Pays_Fine_By_Bank_Transfer()
        {
            irma.SetFineLimit(20M);
            irma.PayFine(7M);
            Assert.Equal(13M, irma.GetFineCredit());
        }

        // TODO - Now nothing is lost when ittzy becomes an adult
        [Fact]
        public void Junior_Becomes_Adult()
        {
            ittzy.SetMembershipType(TypeOfMembership.Adult);
            Book adultBook = library.GetBook(100);
            Assert.True(ittzy.Borrow(adultBook));
            Assert.Equal("1 the High Street", ittzy.Street);
            Assert.Equal("Buddlington", ittzy.City);
            Assert.Equal(25M, ittzy.OustandingFines);
        }
    }
}
