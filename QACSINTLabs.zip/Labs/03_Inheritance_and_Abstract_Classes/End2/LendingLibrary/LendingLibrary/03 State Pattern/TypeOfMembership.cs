﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LendingLibrary
{
    // TODO - invent this such that client s/w does not need to know about the subtypes
    public enum TypeOfMembership
    {
        Junior,
        Adult
    }
}
