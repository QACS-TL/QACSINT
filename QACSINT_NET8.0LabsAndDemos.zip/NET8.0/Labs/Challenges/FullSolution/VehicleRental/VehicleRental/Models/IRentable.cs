﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRental.Models
{
    public interface IRentable
    {
        void Rent();
        void Return();
    }
}
