using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PoliceDispatcher
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class PoliceDispatcherForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtCrime;
		private System.Windows.Forms.TextBox txtLocation;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnAlert;
		private CrimeFightersForm cf;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.ListBox lstSolvedCrimes;
    private Button button1;


		private static PoliceDispatcherForm theInstance;
		public static PoliceDispatcherForm Instance {
			get {
				if( theInstance == null ) {
					theInstance = new PoliceDispatcherForm();
				}
				return theInstance;
			}
		}
		
		private PoliceDispatcherForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void Form1_Load(object sender, System.EventArgs e) {
			cf = new CrimeFightersForm( );
			cf.Owner = this;
			cf.Show();
			cf.DesktopLocation = new Point( this.Right + 5, this.Top );
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			if( cf != null && !cf.IsDisposed ) {
				cf.CloseForm();
			}
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.label1 = new System.Windows.Forms.Label();
      this.txtCrime = new System.Windows.Forms.TextBox();
      this.txtLocation = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.btnAlert = new System.Windows.Forms.Button();
      this.lstSolvedCrimes = new System.Windows.Forms.ListBox();
      this.button1 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(72, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "&Crime:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // txtCrime
      // 
      this.txtCrime.Location = new System.Drawing.Point(104, 16);
      this.txtCrime.Name = "txtCrime";
      this.txtCrime.Size = new System.Drawing.Size(224, 22);
      this.txtCrime.TabIndex = 1;
      this.txtCrime.Text = "Murder";
      // 
      // txtLocation
      // 
      this.txtLocation.Location = new System.Drawing.Point(104, 56);
      this.txtLocation.Name = "txtLocation";
      this.txtLocation.Size = new System.Drawing.Size(224, 22);
      this.txtLocation.TabIndex = 3;
      this.txtLocation.Text = "Gotham City";
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 56);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(72, 23);
      this.label2.TabIndex = 2;
      this.label2.Text = "&Location:";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // btnAlert
      // 
      this.btnAlert.Location = new System.Drawing.Point(240, 96);
      this.btnAlert.Name = "btnAlert";
      this.btnAlert.Size = new System.Drawing.Size(88, 32);
      this.btnAlert.TabIndex = 4;
      this.btnAlert.Text = "&Alert";
      this.btnAlert.Click += new System.EventHandler(this.OnAlertClicked);
      // 
      // lstSolvedCrimes
      // 
      this.lstSolvedCrimes.HorizontalScrollbar = true;
      this.lstSolvedCrimes.ItemHeight = 16;
      this.lstSolvedCrimes.Location = new System.Drawing.Point(8, 144);
      this.lstSolvedCrimes.Name = "lstSolvedCrimes";
      this.lstSolvedCrimes.SelectionMode = System.Windows.Forms.SelectionMode.None;
      this.lstSolvedCrimes.Size = new System.Drawing.Size(320, 212);
      this.lstSolvedCrimes.TabIndex = 5;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(37, 96);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(173, 32);
      this.button1.TabIndex = 6;
      this.button1.Text = "&Report Unsolved Crimes";
      this.button1.Click += new System.EventHandler(this.ReportUnsolvedCrimesClicked);
      // 
      // PoliceDispatcherForm
      // 
      this.AcceptButton = this.btnAlert;
      this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
      this.ClientSize = new System.Drawing.Size(344, 373);
      this.Controls.Add(this.button1);
      this.Controls.Add(this.lstSolvedCrimes);
      this.Controls.Add(this.btnAlert);
      this.Controls.Add(this.txtCrime);
      this.Controls.Add(this.txtLocation);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.label2);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Name = "PoliceDispatcherForm";
      this.Text = "Police Dispatch System";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
      this.ResumeLayout(false);
      this.PerformLayout();

		}
		#endregion


		// TODO: Define an event of type CrimeReportedEventHandler
		// public event CrimeReportedEventHandler CrimeReported; 
        public event EventHandler<CrimeReportedEventArgs> CrimeReported; // from 2005

		private void OnAlertClicked( object sender, System.EventArgs e ) {
			// TODO: Respond to the Alert buttons' Click event and raise
			//       a CrimeReportedEvent but pattern is to raise it in overridable method
			CrimeReportedEventArgs evt = new CrimeReportedEventArgs( txtCrime.Text, txtLocation.Text );
			OnCrimeReported( evt );
		}

		// TODO: Implement the OnCrimeReported method to actually raise the event
		protected virtual void OnCrimeReported( CrimeReportedEventArgs e ) {
      if (CrimeReported == null)  // is no-one registered?
      {
        e.ReasonUnsolved = "All off duty";
        unsolvedCrimeReports.Add(e);
        return;
      }
      
      CrimeReported(this, e);         // do broadcast to 1 or more on duty Crimefighters

      if (e.CrimeFighterOnCase != null)         // Is anybody dealing with it?
      {  
        //e.CrimeFighterOnCase.VillainCaptured += new CrimeReportedEventHandler( OnCrimeSolved );
        e.CrimeFighterOnCase.VillainCaptured += OnCrimeSolved;
      }
      else
      {
        e.ReasonUnsolved = "All busy";
        unsolvedCrimeReports.Add(e);
      }
    
     
		}

		private void OnCrimeSolved( object sender, CrimeReportedEventArgs e ) {
			string s = string.Format( "{0} at {1} solved by {2}", e.Crime, e.Location, e.CrimeFighterOnCase.DisplayName );
			lstSolvedCrimes.Items.Add( s );
      e.CrimeFighterOnCase.VillainCaptured -= OnCrimeSolved; // using inferred delegate type
		}
    private void CrimeUnSolved(CrimeReportedEventArgs e)
    {
      string s = string.Format("{0} at {1} unsolved. {2}", e.Crime, e.Location, e.ReasonUnsolved);
      lstSolvedCrimes.Items.Add(s);
      
    }

    // Optional enhancement to report unsolved crimes.
    private List<CrimeReportedEventArgs> unsolvedCrimeReports = new List<CrimeReportedEventArgs>();

    private void ReportUnsolvedCrimesClicked(object sender, EventArgs e)
    {
      foreach (CrimeReportedEventArgs crea in unsolvedCrimeReports)
      {
        CrimeUnSolved(crea);
      }
      unsolvedCrimeReports.Clear(); // empty the list
    }

	}
}
