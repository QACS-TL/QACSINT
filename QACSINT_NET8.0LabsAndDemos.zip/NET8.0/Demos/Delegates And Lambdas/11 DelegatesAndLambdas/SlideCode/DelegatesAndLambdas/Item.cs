﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndLambdas
{
    public class Item
    {
        public string ValueForFilter { get; set; }
    }
}
