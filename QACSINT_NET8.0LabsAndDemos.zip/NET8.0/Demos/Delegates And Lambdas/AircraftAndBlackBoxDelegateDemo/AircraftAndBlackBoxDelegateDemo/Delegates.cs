﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AircraftAndBlackBoxDelegateDemo
{
    public delegate void AltitudeChangedDelegate(int alt);

    #region "Event Model"
    public delegate void AltitudeChangedEventHandler(object sender, AltitudeChangedEventArgs e);

    public class AltitudeChangedEventArgs : EventArgs
    {
        private int mAltitude;

        public AltitudeChangedEventArgs()
            : this(0)
        {
        }

        public AltitudeChangedEventArgs(int altitude)
        {
            mAltitude = altitude;
        }

        public int Altitude
        {
            get { return mAltitude; }
        }
    }
    #endregion
}
