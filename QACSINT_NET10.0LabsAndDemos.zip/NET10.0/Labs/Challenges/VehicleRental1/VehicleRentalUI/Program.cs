﻿//using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
using VehicleRental.Services;

Console.WriteLine("Welcome to Vehicle Rental System!");

List<Vehicle> vehicles = new List<Vehicle>();

vehicles.AddRange(
    new Car { Id = 1, Model = "Toyota Corolla T", DailyRate = 40m, NumberOfDoors = 4, IsRented = false },
    new Car { Id = 2, Model = "Tesla Model 3 T", DailyRate = 85m, NumberOfDoors = 4, IsRented = false },
    new Motorcycle { Id = 3, Model = "Harley Davidson T", DailyRate = 55m, HasSidecar = false, IsRented = false },
    new Motorcycle { Id = 4, Model = "Honda Gold Wing T", DailyRate = 70m, HasSidecar = true, IsRented = true }
);
var service = new RentalService(vehicles);

bool exit = false;

while (!exit)
{
    Console.WriteLine(@"
        1. View all vehicles
        2. Rent a vehicle
        3. Return a vehicle
        4. Exit");

    Console.Write("> ");
    var input = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(input))
    {
        Console.WriteLine("Please enter a choice.");
        continue;
    }

    if (!int.TryParse(input, out var choice))
    {
        Console.WriteLine("Invalid input. Enter a number.");
        continue;
    }


    if (choice == 1)
    {
        var all = service.GetAll();
        Print(all);
    }
    else if (choice == 2)
    {
        Console.Write("Enter vehicle ID to rent: ");
        if (int.TryParse(Console.ReadLine(), out var id))
        {
            string message = service.Rent(id);
            Console.WriteLine(message);
        }
        else
        {
            Console.WriteLine("Invalid ID.");
        }
    }
    else if (choice == 3)
    {
        Console.Write("Enter vehicle ID to return: ");
        if (int.TryParse(Console.ReadLine(), out var id))
        {
            string message = service.Return(id);
            Console.WriteLine(message);
        }
        else
        {
            Console.WriteLine("Invalid ID.");
        }
    }
    else if (choice == 4)
    {
        exit = true;
    }
    else
    {
        Console.WriteLine("Unknown option. Try again.");
    }

}

static void Print(IEnumerable<VehicleRental.Models.Vehicle> vehicles)
{
    var list = vehicles.ToList();
    if (list.Count == 0)
    {
        Console.WriteLine("(no vehicles)");
        return;
    }

    foreach (var v in list)
    {
        Console.WriteLine($"{v.Id}. {v}");
    }
}

Console.WriteLine("Goodbye!");